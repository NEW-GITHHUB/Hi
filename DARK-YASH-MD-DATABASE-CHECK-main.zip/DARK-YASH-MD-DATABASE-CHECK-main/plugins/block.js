const {cmd , commands} = require('../command')


cmd({
    pattern: "block",
    desc: "block user",
    category: "owner",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
await conn.sendMessage(from, { react: { text: '↔️', key: mek.key } });

if(!isOwner) {
const rc = await conn.sendMessage(from,{text:"⛔ *THIS IS AN OWNER COMMAND.*"},{quoted:mek})
const reactionMessage = {react: {text: "⛔", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
 } 
if (isGroup) return
let ef = await conn.sendMessage(from,{text:"*User Bloked ✅*"},{quoted:mek})
await conn.sendMessage(from, { react: { text: '✅', key: ef.key } });

await conn.updateBlockStatus(from, "block")
}catch(e){
console.log(e)
let df = await conn.sendMessage(from,{text:"🛑 *DARK YASH MD ERROR*`"},{quoted:mek})
await conn.sendMessage(from, { react: { text: '❗', key: df.key } });
}
})
