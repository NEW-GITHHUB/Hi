const { cmd, commands } = require('../command');
const { fetchJson } = require('../lib/functions');

cmd({
    pattern: "trt",
    alias: ['translate'],
    category: "convert",
    filename: __filename,
    desc: "Translate's given text in desired language."

}, async (conn, mek, m, { from, quoted, body, args, q, reply }) => {

await conn.sendMessage(from, { react: { text: '🔤', key: mek.key } });

if(!m.quoted && !m.mentionJid) {
const rc = await conn.sendMessage(from,{text:"*❌ Please provide a text to translate*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
const { translate } = require('@vitalets/google-translate-api');

let lang = `${q}`;
if(!lang) {
const rcr = await conn.sendMessage(from,{text:"❌ *Please provide a language to translate*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rcr.key }}
return await conn.sendMessage(from, reactionMessage)
}
let text;
if (m.quoted.conversation) {
text = m.quoted.conversation;
} else if (m.quoted.imageMessage && m.quoted.imageMessage.caption) {
text = m.quoted.imageMessage.caption;
} else if (m.quoted.videoMessage && m.quoted.videoMessage.caption) {
text = m.quoted.videoMessage.caption;
} else {
return;  
}

try {
const response = await translate(text, { to: lang });
let sendtrt = await conn.sendMessage(from, { text: `*🔴 TRANSLATED INTO : ${lang}*\n\n🔵 ${response.text}\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*` }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: sendtrt.key } });
        
} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
});



cmd({
    pattern: "cal",
    desc: "...",
    category: "mathtool",
    use: '.cal',
    filename: __filename
}, 

async (conn, mek, m, { from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {
await conn.sendMessage(from, { react: { text: '➕', key: mek.key } });

if(!q) {
const rc = await conn.sendMessage(from,{text:"❌ *Please give me number...*\n\n‼️ *EXAMPLE :-*‼️\n\n> *.cal 12+12 : PLUS* \n> *.cal 12-12 : MINUS*\n> *.cal 12÷12 : DIVIDED*\n> *.cal 12×12 : MULTIPLY*"},{quoted:mek})
const reactionMessage = {react: {text: "❗", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
const math = require('mathjs');
const result = math.evaluate(q);
//reply(`🗣️ *According to Your Question, The Answer is Given Below*\n\n*\`${q}\`* = *${result}*\n\n● *ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ* ●`);
let sendanswer = await conn.sendMessage(from, { text: `🗣️ *ACCORDING TO YOUR QUESTION, THE ANSWER IS GIVEN BELOW*\n\n✍️ *\`${q}\`* = *${result}*\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*` }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: sendanswer.key } });

} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e);
}
});
