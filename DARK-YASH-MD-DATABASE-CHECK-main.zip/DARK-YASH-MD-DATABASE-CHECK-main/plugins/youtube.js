const {readEnv} = require('../lib/database')
const { fetchJson } = require('../lib/functions')
const {cmd , commands} = require('../command')
const fs = require('fs')

const fg = require('api-dylux')
const yts = require('yt-search')

function convertToStandardYouTubeURL(url) {
const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
const match = url.match(regex);
if (match && match[1]) {
const videoId = match[1];
return `https://www.youtube.com/watch?v=${videoId}`;
 } else {
return url;
}
}
//===========================SONG DOWNLOAD CMD=========================== 

cmd({
    pattern: "song",
    desc: "download song",
    category: "download",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()

await conn.sendMessage(from, { react: { text: '🎶', key: mek.key } });
if(!q) {
setTimeout(async () => {
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
}, 500);
return await conn.sendMessage(from , { text: '⚠️ *Please give me a youtube url or title dear*‼️' }, { quoted: m});
await conn.sendMessage(from, { react: { text: '❓', key: m.key } });
}

let mm = convertToStandardYouTubeURL(q)	
const search = await yts(mm)
const data = search.videos[0];
const url = data.url

let desc = `*┠─❲ 🧛 DARK-YASH-MD 🧛 ❳─┨*

    *🎶 SONG DOWNLOADER 🎶*

*┌───────────────────┐*
┝ *ℹ \`Title :\`* ${data.title}
┝ *👤 \`Author :\`* ${data.author.name}
┝ *👁️‍🗨️ \`Views :\`* ${data.views}
┝ *📌 \`Ago :\`* ${data.ago}
┝ *🕘 \`Duration :\`* ${data.timestamp}
┝ *🔗 \`Url :\`* ${data.url}
*└───────────────────┘*

*🔢 select the audio type from bellow...*

  1 | *Audio File 🎶*
  2 | *Document File 📁*
  
 *⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`

//==========NON BUTTON MSG SEND==========

const sentMsg = await conn.sendMessage(from,{image:{url: data.thumbnail},caption:desc},{quoted:mek});
const messageID = sentMsg.key.id; // Save the message ID for later reference


// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

//-----------------------Non Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

 
  // Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1', '2'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

//============DOWNLOAD AUDIO==============
let down = await fg.yta(url)  
let downloadurl = down.dl_url
//========================================

if (messageType === '1') {
// Handle option 1 (Audio File)
let aud = await conn.sendMessage(from,{audio: {url:downloadurl},mimetype:"audio/mpeg"},{quoted:mek});
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✔', key: mek.key } });
//aud send react
await conn.sendMessage(from, { react: { text: '🎧', key: aud.key }});

} else if (messageType === '2') {
// Handle option 2 (Document File)
let doc = await conn.sendMessage(from,{document: {url:downloadurl},mimetype:"audio/mpeg",fileName:data.title + ".mp3",caption:"*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*"},{quoted:mek});
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✔', key: mek.key } });
//aud doc react send
await conn.sendMessage(from, { react: { text: '🎶', key: doc.key }});

/*} else if (messageType === '3') {
// Handle option 3 (Document File)
let audptt = await conn.sendMessage(from, { audio: { url: downloadurl }, mimetype: "audio/mpeg", ptt: true },{ quoted: mek });
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
//aud doc react send
await conn.sendMessage(from, { react: { text: '🎤', key: audptt.key }});*/
}
} else {
// React with invalid input
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
let df = await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1-4) ‼️*' }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❓', key: df.key }})
}
}
});
//========================================================================

}catch(e){
console.log(e)
reply(`⚠️ *DARK YASH MD ERRO➤*‼️ ${e}`)
}
})


//===================video download cmd===================

cmd({
    pattern: "video",
    desc: "download video",
    category: "download",
    filename: __filename
},
async (conn, mek, m, {
from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply
}) => {
try {
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()

await conn.sendMessage(from, { react: { text: '🎥', key: mek.key } });
if(!q) {
setTimeout(async () => {
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
}, 500);
return await conn.sendMessage(from , { text: '⚠️ *Please give me a youtube url or title dear*‼️' }, { quoted: mek});
}

let mm = convertToStandardYouTubeURL(q)	
const search = await yts(mm)
const data = search.videos[0];
const url = data.url

let desc = `*┠─❲ 🧛 DARK-YASH-MD 🧛 ❳─┨*

    *🎥 VIDEO DOWNLOADER 🎥*

*┌───────────────────┐*
┝ *ℹ \`Title :\`* ${data.title}
┝ *👤 \`Author :\`* ${data.author.name}
┝ *👁️‍🗨️ \`Views :\`* ${data.views}
┝ *📌 \`Ago :\`* ${data.ago}
┝ *🕘 \`Duration :\`* ${data.timestamp}
┝ *🔗 \`Url :\`* ${data.url}
*└───────────────────┘*

*🔢 select the video type from bellow...*

*\`[1] Video File\`* 🎥
        1.1 | 240p
        1.2 | 360p 
        1.3 | 480p 
        1.4 | 720p
        1.5 | 1080p
     
*\`[2] Document File\`* 📂
        2.1 | 240p 
        2.2 | 360p 
        2.3 | 480p
        2.4 | 720p
        2.5 | 1080p

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`

const sentMsg = await conn.sendMessage(from, { image: { url: data.thumbnail }, caption: desc }, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference

// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

//-----------------------Non Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

 
// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1.1','1.2','1.3','1.4','1.5','2.1','2.2','2.3','2.4','2.5'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);                

// Set the selected quality and file type
let selectedQuality;
let isDocument = false; // Default to video type

//=====Normal Video Send=====

switch (messageType) {case '1.1':selectedQuality = '240p';break;
case '1.2':selectedQuality = '360p';break;
case '1.3':selectedQuality = '480p';break;
case '1.4':selectedQuality = '720p';break;
case '1.5':selectedQuality = '1080p';break;
                    
//=====Document Type Send=====

case '2.1':selectedQuality = '240p';isDocument = true;break;
case '2.2':selectedQuality = '360p';isDocument = true;break;
case '2.3':selectedQuality = '480p';isDocument = true;break;
case '2.4':selectedQuality = '720p';isDocument = true;break;
case '2.5':selectedQuality = '1080p';isDocument = true;break;

//default:return reply('*⚠️ Invalid selection. Please select a valid number ‼️*');
}

// Download the video with the selected quality
let down = await fg.ytv(url, selectedQuality);
let downloadurl = down.dl_url;

if (!isDocument) {

// Handle normal video file
let vid = await conn.sendMessage(from, { video: { url: downloadurl }, mimetype: "video/mp4", caption: `> *Quality: ${selectedQuality}*\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*`}, { quoted: mek });

// React when the video is uploaded
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: vid.key } });
} else {

// Handle document file
let viddoc = await conn.sendMessage(from, {document: { url: downloadurl }, mimetype: "video/mp4",fileName: `${data.title}.mp4`, caption: `> *Quality: ${selectedQuality}*\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*`}, { quoted: mek });

// React when the document is uploaded
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: viddoc.key } });
}
} else {
// React with invalid inputawait conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1.1-1.5 , 2.1-2.5) ‼️*' }, { quoted: mek });
}
}
});
    
} catch (e) {
console.log(e)
reply(`⚠️ *DARK YASH MD ERRO➤*‼️ ${e}`)
}
})

//===========================YT URL CMD=========================== 

cmd({
    pattern: "yts",
    alias: ["ytsearch"],
    use: '.yts lelena',
    desc: 'Search videos from youtube',
    category: "search",
    filename: __filename

},

async (conn, mek, m, { from, q, reply }) => {
try {
await conn.sendMessage(from, { react: { text: '🔎', key: mek.key }})
if(!q) return await conn.sendMessage(from , { text: '⚠️ *Please give me a title dear*‼️' }, { quoted: mek } )
//if (!q) return await reply('*Please enter a query to search!*')

var result = await yts(q);
var msg = '*🔗 DARK YASH MD YOUTUBE URL SERCH 🔎*\n\n▰▱▰▱▰▱▰▱▰▱▰▱▰\n\n';
result.videos.map((video) => {
msg += 'ℹ️ ' + video.title + '\n\n🎦 ' + video.url + '\n\n▰▱▰▱▰▱▰▱▰▱▰▱▰\n\n'
});
await conn.sendMessage(from,  { image: { url: video.thumbnail  }, caption: msg }, { quoted: mek })

} catch (e) {
console.log(e)
reply('⚠️ *DARK YASH MD Error➤*‼️ ${e}')
}
})


//========================================================================================


/*cmd({
    pattern: "video",
    react: "🎥",
    desc: "download video",
    category: "download",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(!q) return reply("⚠️ *Please give me a youtube url or title dear*‼️")
const search = await yts(q)
const data = search.videos[0];
const url = data.url

let desc = `
*🎥 BLACK FIRE MD YOUTUBE VIDEO DOWNLOADER 📥*

┌──────────────────
┝ *🔖 Title:* ${data.title}
┝ *🤴 Author:* ${data.author.name}
┝ *👀 Views:* ${data.views}
┝ *📆 Ago:* ${data.ago} 
┝ *⏳ Time:* ${data.timestamp}
┝ *🔗 Url:* ${data.url}
└──────────────────

*🔢 Reply with the number of the you want to download...*

  1 | 🎥 *Video Type*
  2 | 📁 *Document Type*

● *ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ* ●
`
//==========NON BUTTON MSG SEND==========

const sentMsg = await conn.sendMessage(from,{image:{url: data.thumbnail},caption:desc},{quoted:mek});
const messageID = sentMsg.key.id; // Save the message ID for later reference


// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 500);

//============DOWNLOAD VIDEO==============
let down = await fg.ytv(url)  
let downloadurl = down.dl_url
//========================================

if (messageType === '1') {
// Handle option 1 (Video File)
let vid = await conn.sendMessage(from,{video: {url:downloadurl},mimetype:"video/mp4"},{quoted:mek});
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
// react video
await conn.sendMessage(from, { react: { text: '📽️', key: vid.key }});
} else if (messageType === '2') {
// Handle option 2 (Document File)
let viddoc = await conn.sendMessage(from,{document: {url:downloadurl},mimetype:"video/mp4",fileName:data.title + ".mp4",caption:"● *ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ* ●"},{quoted:mek});
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
// react viddoc
await conn.sendMessage(from, { react: { text: '📽️', key: viddoc.key }});
}
}
});

}catch(e){
console.log(e)
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
}
})*/

//===========================DARK YASH MD CORDS=========================== 
