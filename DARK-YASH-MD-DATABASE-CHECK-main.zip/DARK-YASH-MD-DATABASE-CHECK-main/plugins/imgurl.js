//=========================================DARK-YASH IMG-URL-CMD================================================================================

const config = require('../config')
const {cmd , commands} = require('../command')
const { fetchJson } = require('../lib/functions')

const FormData = require('form-data');
const axios = require('axios');
const imgbbUrl = 'https://imgbb.com/';
const uploadUrl = 'https://imgbb.com/json';
const maxFileSize = 32 * 1024 * 1024;


//=========================================================================================================================

function generateRandomFilename(length = 8, numberLength = 4) {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
let result = '';
for (let i = 0; i < length; i++) {
result += characters.charAt(Math.floor(Math.random() * characters.length));
}
const number = Math.floor(Math.random() * Math.pow(10, numberLength));
return `${result}${number}`;
}

async function fetchAuthToken() {
try {
const response = await axios.get(imgbbUrl);
const html = response.data;

const tokenMatch = html.match(/PF\.obj\.config\.auth_token="([a-f0-9]{40})"/);
if (tokenMatch && tokenMatch[1]) {
return tokenMatch[1];
}

throw new Error('Auth token not found');
} catch (error) {
console.error('Error fetching auth token:', error.message);
throw error;
}
}
//=========================================================================================================================


// =============================Function to upload image buffer==================================
async function imgurlv2(buffer) {
try {

//==============================Check if the buffer exceeds the maximum file size limit==========
if (buffer.length > maxFileSize) {
return { error: 'File size exceeds 32MB limit' };
}

const authToken = await fetchAuthToken();
const formData = new FormData();

//============================= Generate random filename=======================================
const filename = generateRandomFilename(); 

formData.append('source', buffer, { filename: filename });
formData.append('type', 'file');
formData.append('action', 'upload');
formData.append('timestamp', Date.now());
formData.append('auth_token', authToken);

const uploadResponse = await axios.post(uploadUrl, formData, {
headers: {
...formData.getHeaders(),
},
});

if (uploadResponse.data) {
return uploadResponse.data.image.url; 
} else {
return { error: 'Upload failed, no response data' };
}
} catch (error) {
console.error('Error uploading file:', error.message);
return { error: error.message };
}
}

//======================================================================================================================================================

cmd({
    pattern: "imgurl",
    desc: "img2url",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
await conn.sendMessage(from, { react: { text: '🔗', key: mek.key } });
if(!m.quoted.imageMessage) {
const rc = await conn.sendMessage(from,{text:"❌ *Please Give Me a Image Name*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
let dimg = await m.quoted.download()
let url = await imgurlv2(dimg)
//return reply(url)
//return reply('*✪ 𝙳𝙰𝚁𝙺-𝚈𝙰𝚂𝙷-𝙼𝙳 𝙸𝙼𝙰𝙶𝙴 𝙻𝙸𝙽𝙺 𝚄𝙿𝙻𝙾𝙳𝙴𝚁 ✪*\n\n*🖇️ URL -:* ' + url + '\n');

let senda = await conn.sendMessage(from, { text: `*♻️ Generating and Uploading your Image URL...*` }, { quoted: mek });
let sendanswer = await conn.sendMessage(from, { text: `*📤 UPLOADED YOUR IMAGE URL*\n\n> *${url}*\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*` }, { quoted: mek });

await conn.sendMessage(from, { react: { text: '🔗', key: sendanswer.key } });
await conn.sendMessage(from, { react: { text: '✅', key: senda.key } });

}catch(e){
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
});

//======================================================================================================================================================
/*const { cmd, commands } = require('../command');
let { img2url } = require('@blackamda/telegram-image-url');
const { getRandom } = require('../lib/functions');
const fs = require('fs');
const config = require('../config')

cmd({
    pattern: "img2url",
    react: "🔗",
    alias: ["tourl","imgurl","telegraph","imgtourl"],
    desc: desct,
    category: "convert",
    use: '.img2url <reply image>',
    filename: __filename
},
async(conn, mek, m,{from, l, prefix, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
    try{
    const isQuotedViewOnce = m.quoted ? (m.quoted.type === 'viewOnceMessage') : false
    const isQuotedImage = m.quoted ? ((m.quoted.type === 'imageMessage') || (isQuotedViewOnce ? (m.quoted.msg.type === 'imageMessage') : false)) : false
    if ((m.type === 'imageMessage') || isQuotedImage) {
const fileType = require("file-type");
  var nameJpg = getRandom('');
  let buff = isQuotedImage ? await m.quoted.download(nameJpg) : await m.download(nameJpg)
  let type = await fileType.fromBuffer(buff);
  await fs.promises.writeFile("./" + type.ext, buff);
  img2url("./" + type.ext).then(async url => {
    await reply('*🔗 BLACK FIRE IMAGE LINK DOWNLOADER 📥*\n\n*🖇️ URL -:* ' + url + '\n');
});
} else return reply(imgmsg)

} catch (e) {
reply(cantf);
l(e);
}
})*/
