const { fetchJson } = require('../lib/functions')
const config = require('../config')
const { cmd, commands } = require('../command')

cmd({
    pattern: "help",
    desc: "Help Command",
    category: "main",
    filename: __filename
},
async(conn, mek, m, { from, args, reply }) => {
try {
        
await conn.sendMessage(from, { react: { text: '🤝', key: mek.key } });

if (!args[0]) {
await conn.sendMessage(from, { react: { text: '❓', key: mek.key } });
return await conn.sendMessage(from, { text: '⛔ *Please specify a command name.*' }, { quoted: mek });
}

let responseText;

switch (args[0].toLowerCase()) {
case "fb":
responseText = "The `fb` command allows you to download Facebook videos.";break;
case "song":
responseText = "The `song` command lets you download songs.";break;
case "video":
responseText = "The `video` command allows you to download videos.";break;
default:
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
responseText = "⛔ *Sorry, I don't recognize that command.*";break;
}

await conn.sendMessage(from, { text: responseText }, { quoted: mek });
    
} catch (e) {
console.log(e);
reply(`⚠️ *DARK YASH MD ERRO➤*‼️ ${e}`);
}
});
