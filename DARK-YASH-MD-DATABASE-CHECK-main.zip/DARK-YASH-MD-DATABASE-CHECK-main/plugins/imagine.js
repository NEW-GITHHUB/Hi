const fetch = require( 'node-fetch'); 
const config = require('../config')
const {cmd , commands} = require('../command')
const { fetchJson } = require('../lib/functions')

cmd({
    pattern: "imagine",
    desc: "imagine",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
await conn.sendMessage(from, { react: { text: '✨', key: mek.key } });

if(!q) {
const rc = await conn.sendMessage(from,{text:"❌ *Please Give me a Image name*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
async function imagine(prompt, width = 1024, height = 1024, model = 'flux', seed = -1) {
const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${width}&height=${height}&model=${model}&seed=${seed}`;
const response = await fetch(url);
const buffer = await response.buffer();
 
let senda = await conn.sendMessage(from, { text: `*♻️ Please Wait Generating and Uploading Your Image...*` }, { quoted: mek });
let sendimg = await conn.sendMessage(from,{image:buffer,caption:"*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*"},{quoted:mek});

await conn.sendMessage(from, { react: { text: '✅', key: senda.key } });
await conn.sendMessage(from, { react: { text: '🌟', key: sendimg.key } });

}
  
await imagine(q)
  
}catch(e){
console.log(e)
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*`"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
}
})
