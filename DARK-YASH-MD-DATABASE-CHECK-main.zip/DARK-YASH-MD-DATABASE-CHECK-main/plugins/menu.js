const {readEnv} = require('../lib/database')
const {cmd , commands} = require('../command')
const fs = require('fs')
const os = require("os")
const path = require('path');
const voiceFilePath = path.join(__dirname, '../lib/dark_yash_md_sound.mp3');
const {runtime} = require('../lib/functions')
const moment = require('moment-timezone');


cmd({
    pattern: "menu",
    desc: "To get the menu.",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()

await conn.sendMessage(from, { react: { text: '🛍️', key: mek.key }});

const currentTime = moment().tz('Asia/Colombo').format('hh:mm ');   
const currentDate = moment().tz('Asia/Colombo').format('YYYY-MM-DD');


function getTimeOfDay() {
const hour = moment().tz('Asia/Colombo').hour();
if (hour >= 0 && hour < 12) {
return 'Good morning 💐🌞';
} else if (hour >= 12 && hour < 15) {
return 'Good Afternoon';
} else if (hour >= 15 && hour < 18) {
return 'Good Evening';
} else if (hour >= 18 && hour < 24) {
return 'Good night! 💤🛌💤';
}
}
    
let menumsg = `*👋 𝗛𝗘𝗟𝗟𝗢...${pushname}...*
   
*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⏰ ɴᴏᴡ ᴛɪᴍᴇ -* ${currentTime}
┃ *➩📆 ɴᴏᴡ ᴅᴀᴛᴇ -* ${currentDate}
┃ *➩⚙️ ʀᴀᴍ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
*╰────────────⦁⦁➤*
╭─────────────⦁⦁➤
┃ *⛵ LIST PANEL*
┃⦁──────────⦁
├ 📥  1 | *DOWNLOAD*
├ 🔄  2 | *CONVERT*
├ 🔎  3 | *SERCH*
├ 👨‍💻  4 | *OWNER*
├ 🪀  5 | *GROUP*
├ 🫅  6 | *MAIN*
├ ✨  7 | *AI*
├ 🎳  8 | *GAME*
├ 🧣  9 | *OTHER*
├ 📃 10 | *ALL CMD*
╰─────────────⦁⦁➤

*💥 Reply the Number you want to select*
`
let downloadmenu = `*👋 Hellow ${pushname}*...

*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*
╭──────────────⦁⦁➤
┃ *📥 DOWNLOAD MENU*
┃ *⦁─────────────⦁*
├📥  .song
├📥  .video
├📥  .fb
├📥  .tiktok
├📥  .ig
├📥  .twitter
├📥  .mediafire
├📥  .gdrive
├📥  .wamod
├📥  .apk
├📥  .img
╰─────────────⦁⦁➤

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`

let convertmenu = `*👋 Hellow ${pushname}*...  

*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*
╭──────────────⦁⦁➤
┃ *🔄 CONVERT MENU*
┃ *⦁─────────────⦁*
├ 🔄  .img2url
├ 🔄  .sticker
├ 🔄  .surl
├ 🔄  .tts
├ 🔄  .toptt
├ 🔄  .toaudio
├ 🔄  .sticker
├ 🔄  .toimg
├ 🔄  .trt
├ 🔄  .toimg
╰─────────────⦁⦁➤

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`
let serchmenu = `*👋 Hellow ${pushname}*...  

*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*
╭──────────────⦁⦁➤
┃ *🔍 SEARCH MENU*
┃ *⦁─────────────⦁*
├🔍  .findtiktok
├🔍  .findapk
├🔍  .yts
├🔍  .weather
├🔍  .git
├🔍  .sporty
╰─────────────⦁⦁➤

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`
let ownermenu = `*👋 Hellow ${pushname}*...  

*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*
╭──────────────⦁⦁➤
┃ *👨‍💻 OWNER MENU*
┃ *⦁─────────────⦁*
├👨‍💻  .send
├👨‍💻  .alljid
├👨‍💻  .name
├👨‍💻  .about 
├👨‍💻  .restart
├👨‍💻  .boom
├👨‍💻  .vv
├👨‍💻  .update
╰─────────────⦁⦁➤

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`
let groupmenu = `*👋 Hellow ${pushname}*... 

*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*
╭──────────────⦁⦁➤
┃ *🪀 GROUP MENU*
┃ *⦁─────────────⦁*
├🪀  .mute
├🪀  .unmute
├🪀  .promote 
├🪀  .demote
├🪀  .invite
├🪀  .kick
├🪀  .left
├🪀  .gname
├🪀  .gdec
├🪀  .gdp
├🪀  .del
╰─────────────⦁⦁➤

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`
let mainmenu = `*👋 Hellow ${pushname}*... 

*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*
╭──────────────⦁⦁➤
┃ *🫅 MAIN MENU*
┃ *⦁─────────────⦁*
├🤴  .alive
├🤴  .menu
├🤴  .ping
├🤴  .system
├🤴  .news
├🤴  .list
├🤴  .today
├🤴  .restart
├🤴  .jid
├ 🤴 .logo
├🤴  .script
╰─────────────⦁⦁➤

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`
let aimenu = `
*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*

`
let funmenu = `
*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*

`
let othermenu = `
*╭─「👹ᴄᴏᴍᴍᴀɴᴅꜱ ᴘᴀɴᴇʟ👹」*
┃ *➩⚙️ ʀᴜɴ ᴜꜱᴀɢᴇ -* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB 
┃ *➩⚙️ ʀᴀᴍ ᴛɪᴍᴇ -*  ${runtime(process.uptime())} 
*╰─────────────⦁⦁➤*

`


// Send the initial message and store the message ID
await conn.sendMessage(from,{ audio: { url:voiceFilePath }, mimetype:'audio/mpeg', ptt: true },{ quoted: mek });

const sentMsg = await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: menumsg }, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference


// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

//-----------------------Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

    
// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// React to the user's reply (the "1" or "2" message)
//await conn.sendMessage(from, { react: { text: '🆗', key: mek.key } });

if (messageType === '1') {
// Handle option 1 (Audio File)
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: downloadmenu }, { quoted: mek });
} else if (messageType === '2') {
// Handle option 2 (Document File)
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: convertmenu }, { quoted: mek });
} else if (messageType === '3') {
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: serchmenu }, { quoted: mek });
} else if (messageType === '4') {
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: ownermenu }, { quoted: mek });
} else if (messageType === '5') {
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: groupmenu }, { quoted: mek });
} else if (messageType === '6') {
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: mainmenu }, { quoted: mek });
} else if (messageType === '7') {
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: aimenu }, { quoted: mek });
} else if (messageType === '8') {
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: funmenu }, { quoted: mek });
} else if (messageType === '9') {
await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: othermenu }, { quoted: mek });
}

// React to the successful completion of the task
}
});

} catch (e) {
console.log(e);
reply(`⚠️ *DARK YASH MD ERRO➤*‼️ ${e}`);
}
});
