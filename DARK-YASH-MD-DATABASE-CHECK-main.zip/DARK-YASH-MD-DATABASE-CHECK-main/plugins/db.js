const {readEnv} = require('../lib/database')
const { fetchJson } = require('../lib/functions')
const {cmd , commands} = require('../command')
const fs = require('fs')

let currentPollIndex = 0;
let ytsOptionIndex = 1;
const ytsSearchResults = new Map();
let props;
const audioSearchResults = new Map();
let optionIndex = 1;
let index = 1;
const videoSearchResults = new Map();
let titleUrlMap = {}; 
const userContextMap = new Map();

cmd({
    pattern: "db",
    react: "",
    desc: "Check bot online or no.",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()
const config = await readEnv();

//-----------------------Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

let dp = `*👋 𝗛𝗘𝗟𝗟𝗢 ${pushname}...*\n
`
const categories = [];
const categoryMap = new Map();

for (let i = 0; i < 1; i++) {
const cmd = commands[i];
if (!cmd.dontAddCommandList && cmd.pattern !== undefined) {
const category = cmd.category.toUpperCase();
if (!categoryMap.has(category)) {
categories.push(category);
categoryMap.set(category, []);
}
categoryMap.get(category).push(cmd.pattern);
}
}
const rows = []
for (const category of categories) {


             rows.push({
                    header: "",
                    title: "DATABASE CURRENT STIRING",
                    description: "Lowest quality, samallest file size ",
                    id: `.ss`
                
                }),
                rows.push({
                    header: "",
                    title: "DATABASE CHANGE ADD MSG",
                    description: "standard quality, small file size",
                    id: `.cp`
                
                }),
                rows.push({
                    header: "",
                    title: "NEXT AGAIN",
                    description: "",
                    id: `.db`
                
                })
	   }
		
const rows2 = []
for (const category of categories) {
        
        rows2.push({
                    header: "",
                    title: "DATABAE CMD CURRENT STIRING",
                    description: "",
                    id: `.sss`
                
                }),
		rows2.push({
                    header: "",
                    title: "DATABASE CMD CHANGE MSG",
                    description: "",
                    id: `.cps`
                
                }),
	    rows2.push({
                    header: "",
                    title: "NEXT AGAIN",
                    description: "",
                    id: `.db`
    
                })	

           }     
            
    let buttons = [{
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
            display_text: config.DB_NAME,
            url: config.DB_URL,
            merchant_url: config.DB_URL
            }),
            },
            {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                title: 'SELECT OPTIONS ✨',
                sections: [{
                title: 'Please select the you want from bellow',
                highlight_label: 'DARK-YASH-MD',
                rows: rows

                }]
                }),
                },
                {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                title: 'SELECT DETAILS 🔑',
                sections: [{
                title: 'Please select the you want form bellow',
                highlight_label: 'DARK-YASH-MD',
                rows: rows2

                }]
                }),
                }                       
            ]
 let message = {
                image: config.DB_IMG,
                header: '',
                footer: config.DB_FOOTER,
                body: dp

            }
return await conn.sendButtonMessage(from, buttons, m, message)
} catch (e) {
reply('*Error !!*')
console.log(e)
}
});

cmd({
    pattern: "cp",
    react: "",
    desc: "Check bot online or no.",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()
const config = await readEnv();

//-----------------------Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

let dpp = `*👋 𝗛𝗘𝗟𝗟𝗢 ${pushname}...*\n
`
let buttons = [{
    name: "cta_url",
    buttonParamsJson: JSON.stringify({
        display_text: config.DB_NAME,
        url: config.DB_URL,
        merchant_url: config.DB_URL
    }),
 },
 {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "WORK_TYPE_CODE",
    copy_code: `.update MODE: public`  
    }),
   },
   {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "ALIVE_IMG_CODE",
    copy_code: `.update ALIVE_IMG:`  
    }),
    },
    {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "ALIVE_MSG_CODE",
    copy_code: `.update ALIVE_MSG:`  
    }),
    },
    {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "PREFIX_CODE",
    copy_code: `.update PREFIX:`  
    }),
    },
    {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "AUTO_RELY_CODE",
    copy_code: `.update AUTO_RELY:`  
    }),
    },
    {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "AUTO_STICKER_CODE",
    copy_code: `.update AUTO_STICKER:`  
    }), 
    
      }
    ]
        let opts = {
            image:  config.DB_IMG,
            header: '',
            footer: config.DB_FOOTER,
            body: dpp
        

        }
        return await conn.sendButtonMessage(from, buttons, m, opts)
    } catch (e) {
        reply('*Error !!*')
        console.log(e)
    }
}) 


cmd({
    pattern: "ss",
    desc: "update bot settings",
    category: "updates",
    filename: __filename
},
async(conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try{
const config = await readEnv();


const caption = `*⚙️ DARK YASH CURRENT SETTINGS* ⚙️

*┎──────────────────────┓*
*├ \`➤ PREFIX:\`* ${config.PREFIX}
*├ \`➤ POWER:\`* on
*├ \`➤ LANGUAGE:\`* Sinhala
*├ \`➤ BUTTONS:\`* true
*├ \`➤ WORK_TYPE:\`* ${config.MODE}
*├ \`➤ AUTO_VOICE:\`* ${config.AUTO_VOICE}
*├ \`➤ AUTO_STICKER:\`* ${config.AUTO_STICKER}
*├ \`➤ AUTO_REPLY:\`* ${config.AUTO_REPLY}
*├ \`➤ ALWAYS_ONLINE:\`* true
*├ \`➤ AUTO_READ_STATUS:\`* ${config.AUTO_READ_STATUS}
*├ \`➤ MAX_SIZE:\`* 200
*├ \`➤ SUDO:\`* ${config.SUDO}
*├ \`➤ LOGO:\`* ${config.ALIVE_IMG}
*├ \`➤ ALIVE_MSG:\`* ${config.ALIVE_MSG}
*┕──────────────────────┚*

*📂 MONGODB Rate limit remaining:* \`${config.MONGO_RATE}\`
 
*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`
       
await conn.sendMessage(from,  { image: { url: config.EV_IMAGE }, caption: caption }, { quoted: mek })

}catch(e){
console.log(e)
reply(`⚠️ *DARK YASH MD Error➤*‼️ ${e}`)
}
});


cmd({
    pattern: "sss",
    desc: "update bot settings",
    category: "updates",
    filename: __filename
},
async(conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try{
const config = await readEnv();

const caption = `*👋 𝗛𝗘𝗟𝗟𝗢 ${pushname}...*

*👨‍🔧 DARK YASH DB CMD CURRENT MSG 👨‍🔧*

- *\`DB_NAME:\`* ${config.DB_NAME}
- *\`DB_URL:\`* ${config.DB_URL}
- *\`DB_IMG:\`* ${config.DB_IMG}
- *\`DB_FOOTER:\`* ${config.DB_FOOTER}
- *\`DB_MSG:\`* ${config.DB_MSG}

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
` 
await conn.sendMessage(from,  { image: { url: config.EV_IMAGE }, caption: caption }, { quoted: mek })
       
//await conn.sendMessage(from, { text: caption }, { quoted: mek })

}catch(e){
console.log(e)
reply(`⚠️ *DARK YASH MD Error➤*‼️ ${e}`)
}
});

cmd({
    pattern: "cps",
    react: "",
    desc: "Check bot online or no.",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()
const config = await readEnv();

//-----------------------Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

let dps = `*👋 𝗛𝗘𝗟𝗟𝗢 ${pushname}...*\n
`
let buttons = [{
    name: "cta_url",
    buttonParamsJson: JSON.stringify({
        display_text: config.DB_NAME,
        url: config.DB_URL,
        merchant_url: config.DB_URL
    }),
 },
 {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "DB_NAME_CODE",
    copy_code: `.update DB_NAME:`  
    }),
   },
   {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "DB_URL_CODE",
    copy_code: `.update DB_URL:`  
    }),
    },
    {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "DB_IMG_CODE",
    copy_code: `.update DB_IMG:`  
    }),
    },
    {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "DB_MSG_CODE",
    copy_code: `.update DB_MSG:`  
    }),
    },
    {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
    display_text: "DB_FOOTER_CODE",
    copy_code: `.update DB_FOOTER:`  
    }),
    
       } 
    ]
        let opts = {
            image:  config.DB_IMG,
            header: '',
            footer: config.DB_FOOTER,
            body: dps
        

        }
        return await conn.sendButtonMessage(from, buttons, m, opts)
    } catch (e) {
        reply('*Error !!*')
        console.log(e)
    }
}) 
    
