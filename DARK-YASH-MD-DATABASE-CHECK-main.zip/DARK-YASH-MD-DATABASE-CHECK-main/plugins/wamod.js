const {readEnv} = require('../lib/database')
const { fetchJson } = require('../lib/functions');
//const config = require('../config');
const fs = require('fs')
const { cmd, commands } = require('../command');

cmd({
    pattern: "wamod",
    alias: ["whatsappmod"],
    react: "🪀", // Initial reaction emoji
    desc: "wamod download",
    category: "download",
    use: '.wamod',
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()
await conn.sendMessage(from, { react: { text: '🪀', key: mek.key }})
const caption = `🪀 BLACK FIRE MD WAMOD DOWNLOADER 📥

1 | Found Whatsapp
2 | FM Whatsapp
3 | GB Whatsapp
4 | YO Whatsapp

🔢 \Select The WhatsApp Type Above...\

● ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ ●`;

let foundwa = `> FOUND WHATSAPP
● ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ ●`;
let fmwa = `> FM WHATSAPP
● ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ ●`;
let gbwa = `> GB WHATSAPP
● ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ ●`;
let yowa = `> YO WHATSAPP
● ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ ●`;

// Send the initial message
const sentMsg = await conn.sendMessage(from, {image: { url: 'https://photo2.tinhte.vn/data/attachment-files/2024/03/8295590_Blue_WhatsApp_Plus_APK.jpg' },caption: caption}, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference

// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

//-----------------------Non Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1', '2', '3', '4'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);


// Handle each option based on user input
if (messageType === '1') {
// Handle option 1 (Found Whatsapp)
let found = await conn.sendMessage(from, {document: { url: 'https://apk-download.co/V1010F/WA10.10F@FouadMODS.apk' },mimetype: 'application/vnd.android.package-archive',fileName: 'FOUNDWhatsapp',caption: foundwa}, { quoted: mek });
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
// React With Doc File
await conn.sendMessage(from, { react: { text: '📂', key: found.key } });

} else if (messageType === '2') {
// Handle option 2 (FM Whatsapp)
let fm = await conn.sendMessage(from, {document: { url: 'https://dl.gbroid.net/Fmwhatsapp_new.apk' },mimetype: 'application/vnd.android.package-archive',fileName: 'FMWhatsaApp.apk',caption: fmwa}, { quoted: mek });
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
// React With Doc File
await conn.sendMessage(from, { react: { text: '📂', key: fm.key } });

} else if (messageType === '3') {
// Handle option 3 (GB Whatsapp)
let gb = await conn.sendMessage(from, {document: { url: 'https://apk-download.co/V1010F/GBWA10.10F@FouadMODS.apk' },mimetype: 'application/vnd.android.package-archive',fileName: 'GBWhatsaApp.apk',caption: gbwa}, { quoted: mek });
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
// React With Doc File
await conn.sendMessage(from, { react: { text: '📂', key: gb.key } });

} else if (messageType === '4') {
// Handle option 4 (YO Whatsapp)
let yo = await conn.sendMessage(from, {document: { url: 'https://apk-download.co/V1010F/YOWA10.10F@FouadMODS.apk' },mimetype: 'application/vnd.android.package-archive',fileName: 'YOWhatsaApp.apk',caption: yowa}, { quoted: mek });
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
// React With Doc File
await conn.sendMessage(from, { react: { text: '📂', key: yo.key } });
}

} else {
// React with invalid input
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
await conn.sendMessage(from, { text: '⚠️ Invalid option! Please enter a valid number (1-4) ‼️' }, { quoted: mek });
}
}
});

} catch (e) {
console.log(e)
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
}
});
