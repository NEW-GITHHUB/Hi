const config = require('../config')
const { Sticker, createSticker, StickerTypes } = require("wa-sticker-formatter");
const { cmd, commands } = require('../command')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')

cmd({
    pattern: "sticker",
    alias: ["s","stic"],
    desc: "sticker generator",
    category: "convert",
    use: '.sticker <Reply to image>',
    filename: __filename

},
async (conn, mek, m, {from, quoted, q, reply}) => {
try {
await conn.sendMessage(from, { react: { text: '💫', key: mek.key } });

const isQuotedImage = m.quoted ? (m.quoted.type === 'imageMessage') : false;
const isQuotedSticker = m.quoted ? (m.quoted.type === 'stickerMessage') : false;

if(!isQuotedImage && !isQuotedSticker) {
const rc = await conn.sendMessage(from,{text:"❌ *Please reply to an Image or Sticker*"},{quoted:mek});
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
if (isQuotedImage) {
var nameJpg = getRandom('');
await m.quoted.download(nameJpg);
let sticker = new Sticker(nameJpg + '.jpg', {
pack: 'DARK YASH MD',
author: 'Created By M.G.MANTHILA',
type: q.includes("--crop" || '-c') ? StickerTypes.CROPPED : StickerTypes.FULL,
categories: ["🤩", "🎉"],
id: "12345",
quality: 75,
background: "transparent",
});

const uploadingMessage = await conn.sendMessage(from, { text: '*♻️ Generating and Uploading your sticker...*' }, { quoted: mek });
const buffer = await sticker.toBuffer();
const sreact = await conn.sendMessage(from, { sticker: buffer }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: uploadingMessage.key } });
await conn.sendMessage(from, { react: { text: '✨', key: sreact.key } });

} else if (isQuotedSticker) {
var nameWebp = getRandom('');
await m.quoted.download(nameWebp);
let sticker = new Sticker(nameWebp + '.webp', {
pack: 'DARK-YASH-MD',
author: 'Created By M.G.MANTHILA',
type: q.includes("--crop" || '-c') ? StickerTypes.CROPPED : StickerTypes.FULL,
categories: ["🤩", "🎉"],
id: "12345",
quality: 75,
background: "transparent",
});

const uploadingMessage = await conn.sendMessage(from, { text: '*♻️ Generating and Uploading your sticker...*' }, { quoted: mek });
const buffer = await sticker.toBuffer();
const sreact = await conn.sendMessage(from, { sticker: buffer }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: uploadingMessage.key } });
await conn.sendMessage(from, { react: { text: '✨', key: sreact.key } });

}
} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e);
}
});
