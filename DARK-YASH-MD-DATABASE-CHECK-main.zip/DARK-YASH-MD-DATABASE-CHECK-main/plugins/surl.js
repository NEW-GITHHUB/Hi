const config = require('../config')
const {cmd , commands} = require('../command')
const { fetchJson } = require('../lib/functions')
const axios = require('axios')
cmd({
    pattern: "surl",
    desc: "long url to short url",
    category: "download",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
await conn.sendMessage(from, { react: { text: '🖇️', key: mek.key } });

if(!q) {
const rc = await conn.sendMessage(from,{text:"*❌ Please Give Me a URL*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
if(!q.startsWith("https://")) return reply("*❌ Wrong Not URL*")

let data = await axios.get(`https://tinyurl.com/api-create.php?url=${q}`);


let senda = await conn.sendMessage(from, { text: `*♻️ Generating and Uploading your Short URL...*` }, { quoted: mek });
return await sleep(1000); 
let sendanswer = await conn.sendMessage(from, { text: `*📤 UPLOADED YOUR SHORT URL*\n\n> *${data.data}*\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*` }, { quoted: mek });

await conn.sendMessage(from, { react: { text: '🔗', key: sendanswer.key } });
await conn.sendMessage(from, { react: { text: '✅', key: senda.key } });

}catch(e){
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
});
