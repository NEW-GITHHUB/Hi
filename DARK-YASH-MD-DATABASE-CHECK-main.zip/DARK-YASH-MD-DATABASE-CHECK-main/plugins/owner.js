const config = require('../config');
const { cmd, commands } = require('../command');
const { fetchJson } = require('../lib/functions');

cmd({
    pattern: "owner",
    desc: "Send owner contact",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
const ownernumber = '94742614390';
try {

await conn.sendMessage(from, { react: { text: '🤴', key: mek.key } });
let sendcontact = await conn.sendMessage(from, {contacts: {displayName: 'Hasaga Dilshan-Black Fire MD Creater',contacts: [{ vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Hasaga Dilshan-Black Fire MD Creater\nTEL;type=CELL;type=VOICE;waid=${ownernumber}:${ownernumber}\nEND:VCARD` }]}}, { quoted: m });
await conn.sendMessage(from, { react: { text: '✅', key: sendcontact.key } });

} catch (error) {
        
console.error('*⛔ Error sending owner contact:*', error);
if (reply) {await reply('⛔ *Error sending owner contact*');}
await m.React("❌");
}
});
