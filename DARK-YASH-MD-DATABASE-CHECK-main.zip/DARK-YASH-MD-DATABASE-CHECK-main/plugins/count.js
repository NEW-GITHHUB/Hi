const { cmd, commands } = require('../command');

cmd({
    pattern: "count",
    desc: "count char",
    category: "owner",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {

await conn.sendMessage(from, { react: { text: '🔢', key: mek.key } });

let targetText = q || (m.quoted && m.quoted.msg) ? m.quoted.msg : null;

if (!targetText) {
await conn.sendMessage(from, { react: { text: '⁉️', key: mek.key } });
return await conn.sendMessage(from, { text: '*⛔ Please mention a text message*' }, { quoted: mek });
}

let charCount = targetText.length;
let wordCount = targetText.trim().split(/\s+/).length;
let paragraphCount = targetText.trim().split(/\n+/).length;

const charLimit = 30000;

if (charCount > charLimit) {
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
return await conn.sendMessage(from, { text: `⛔ *Message exceeds the character limit of ${charLimit}. Current count: ${charCount}*` }, { quoted: mek });
}

let countMessage = `🔵 *character count: ${charCount}*\n🟢 *word count: ${wordCount}*\n🟣 *paragraph count: ${paragraphCount}*\n\n● *ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ* ●`;
let countchar = await conn.sendMessage(from, { text: countMessage }, { quoted: mek });
return await conn.sendMessage(from, { react: { text: '✅', key: countchar.key } });

} catch (err) {
console.error(err);
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
await conn.sendMessage(from, { text: '⛔ *An error occurred while processing your request*' }, { quoted: mek });
}
});
