const config = require('../config')
const { cmd, commands } = require('../command')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')

cmd({
        pattern: "restart",
        desc: "To restart bot",
        category: "owner",
        filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, isMe, command, args, q, isdev, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isCreator, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{   
if(!isOwner) {
const rc = await conn.sendMessage(from,{text:"⛔ *THIS IS AN OWNER COMMAND.*"},{quoted:mek})
const reactionMessage = {react: {text: "⛔", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}

const mass = await conn.sendMessage(from, { text: "restarting"}, { quoted: mek });
await conn.sendMessage(m.chat, {  react: {  text: "🔄",   key: mass.key }})
const { exec } = require("child_process") 
exec('pm2 restart all')

} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
})

//==================================================================================================================================================================

/*const config = require('../config')
const {cmd , commands} = require('../command')
const {sleep} = require('../lib/functions')

cmd({
    pattern: "restart",
    desc: "restart the bot",
    category: "owner",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
return if(!isOwner)
const {exec} = require("child_process")
reply("🥷 Restarting Black Fire MD...")
await sleep(1500)
exec("pm2 restart all")

}catch(e){
console.log(e)
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
}
})*/

//=========================BLACK FIRE MD CORDS=========================
