const {cmd}=require('../command')

cmd({
    pattern: "name",
    desc: "chnange wa acc name",
    category: "owner",
    filename: __filename
},

async (conn, mek, m, { from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    
 if (!isOwner) {
        return reply("this owner cmd");
    }

 if (!q) {
        return reply("please give me name");
    }

await conn.updateProfileName(q)
return reply("done ✅")
})
