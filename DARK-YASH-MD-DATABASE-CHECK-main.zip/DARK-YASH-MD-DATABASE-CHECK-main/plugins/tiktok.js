//==============================DARK YASH TIKTOK DOWNLOAD COMMAND==============================
const {readEnv} = require('../lib/database')
const {cmd , commands} = require('../command')
const fs = require('fs')
const axios = require('axios')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')

//=============================ttdl scrapper==================================== 
async function tiktokdl(query) {
return new Promise(async (resolve, reject) => {
try {
const encodedParams = new URLSearchParams();
encodedParams.set("url", query);
encodedParams.set("hd", "1");

const response = await axios({
method: "POST",
url: "https://tikwm.com/api/",
headers: {
"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
Cookie: "current_language=en",
"User-Agent":
"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
},
data: encodedParams,
});
const videos = response.data;
resolve(videos);
} catch (error) {
// reply(`${error}`)
}
});
}
//=============================ttdl scrapper==================================== 


cmd({
    pattern: "tiktok",
    alias: ["ttwm"],
    desc: "Download tiktok videos",
    category: "download",
    use: '.tiktok3 <tiktok link>',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()
    
await conn.sendMessage(from, { react: { text: '💥', key: mek.key }})
//if(!q) return await conn.sendMessage(from , { text: '*⚠️ Please give me tiktok url dear‼️*' }, { quoted: mek } )
if(!q) {
const rc = await conn.sendMessage(from,{text:"❌ *Please Give Me a Tiktok URL.*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
let data = await tiktokdl(q)

let desc = `❍⚯──────────────────────⚯❍
     *🧧 DARK-YASH-MD TIKTOK DL 🧧*
❍⚯──────────────────────⚯❍

*\`➤ Title :\`* ${data.data.title}

*\`➤ Profile_Name:\`* ${data.data.author.nickname}

*\`➤ Country:\`* ${data.data.region}

┏━━━━━━━━━━━━━━━━━━━┓
┣ 💬 *Comments:* ${data.data.comment_count}
┣ 🔀 *Share:* ${data.data.share_count}
┣ 👀 *Views:* ${data.data.play_count}
┣ ⬇️ *Downloads:* ${data.data.download_count}
┣ ⏱️ *Duration:* ${data.data.duration}
┗━━━━━━━━━━━━━━━━━━━┛

🔢 *Please reply with the number you want to select:*

*\`[1] Tiktok Video\`*
       1.1 | 🎟️ With-Watermark
       1.2 | 📼 No-Watermark
       1.3 | 🎫 No-Watermark *[HD]*

*\`[2] Tiktok Audio\`*
       2.1 | 🎶 Audio file
       2.2 | 📁 Document file
       2.3 | 🎤 Voice cut [ptt]

*🖇️ URL:* ${q}

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`


//==========NON BUTTON MSG SEND==========

const sentMsg = await conn.sendMessage(from,{image:{url:data.data.cover},caption:desc},{quoted:mek});
const messageID = sentMsg.key.id; // Save the message ID for later reference

// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

//-----------------------Non Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

    
// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1.1', '1.2', '1.3', '2.1', '2.2','2.3'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

if (messageType === '1.1') {
// Handle option 2 (Tiktok Video No Watermark)
let wm = await conn.sendMessage(from, { video: { url: data.data.wmplay }, caption: "- WITH-WATERMARK\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*",}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
await conn.sendMessage(from, { react: { text: '🎥', key: wm.key }})

} else if (messageType === '1.2') {
// Handle option 4 (Tiktok Video No Watermark as Document)
let nowm = await conn.sendMessage(from, { video: { url: data.data.play }, caption: "- NO-WATERMARK\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*",}, { quoted: mek })
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
await conn.sendMessage(from, { react: { text: '🎥', key: nowm.key }})

} else if (messageType === '1.3') {
// Handle option 4 (Tiktok Video No Watermark as Document)
let hdq = await conn.sendMessage(from, { video: { url: data.data.hdplay }, caption: "- HD-QUALITY\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*",}, { quoted: mek })
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
await conn.sendMessage(from, { react: { text: '🎥', key: hdq.key }})

} else if (messageType === '2.1') {
// Handle option 5 (Tiktok Audio File)
let aud = await conn.sendMessage(from, { audio: { url: data.data.music },mimetype:"audio/mpeg"}, { quoted: mek })
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
await conn.sendMessage(from, { react: { text: '🎶', key: aud.key }})

} else if (messageType === '2.2') {
let doc = await conn.sendMessage(from,{document: {url:data.data.music},mimetype:"audio/mpeg",fileName: data.data.title, caption:"*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*"},{quoted:mek})
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
await conn.sendMessage(from, { react: { text: '🎶', key: doc.key }})

} else if (messageType === '2.3') {
// Handle option 5 (Tiktok Audio File)
let vo = await conn.sendMessage(from, { audio: { url: data.data.music },mimetype:'audio/mpeg', ptt: true }, { quoted: mek })
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
await conn.sendMessage(from, { react: { text: '🎙️', key: vo.key }})

}
} else {
// React with invalid input
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
let tt = await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1.1-1.3 , 2.1-2.3) ‼️*' }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❓', key: tt.key } });

}    
}
});

} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console (e)
}
});
//============================== CMD END ==============================



//example output
/*{
  "code": 0,
  "msg": "success",
  "processed_time": 0.4691,
  "data": {
    "id": "7418650363240254753",
    "region": "US",
    "title": "Literally cooked it 👨🏼‍🍳🤝🏽 #transition #metaquest3S #questpartner #mixedreality ",
    "cover": "https://p16-sign-useast2a.tiktokcdn.com/tos-useast2a-p-0037-euttp/2d4363c5617f4023bc0e230ce2eb2f75_1727289147~tplv-tiktokx-cropcenter:300:400.jpeg?dr=14579&nonce=40562&refresh_token=958a4935be9becfc9e80b2b215fc05bd&x-expires=1728097200&x-signature=D%2BAPaBN0CipLuSnP2sNTVjIHiGE%3D&idc=maliva&ps=13740610&s=AWEME_DETAIL&shcp=34ff8df6&shp=d05b14bd&t=4d5b0474",
    "ai_dynamic_cover": "https://p16-sign-useast2a.tiktokcdn.com/tos-useast2a-p-0037-euttp/f90e198f2dbb4a82bc04e2cdaff3468d_1727289147~tplv-tiktokx-origin.image?dr=14575&nonce=35589&refresh_token=81c3fb34eadd29d1129694055dcef4cc&x-expires=1728097200&x-signature=PCrmrXVWqHn4fhwQa%2F054VKVPwQ%3D&idc=maliva&ps=13740610&s=AWEME_DETAIL&shcp=34ff8df6&shp=d05b14bd&t=4d5b0474",
    "origin_cover": "https://p16-sign-useast2a.tiktokcdn.com/tos-useast2a-p-0037-euttp/23c366bf36f34601a9b884f5843a3018_1727289147~tplv-tiktokx-360p.image?dr=14555&nonce=84374&refresh_token=69ff2797d75caef23ee67d1f3279e0db&x-expires=1728097200&x-signature=l6TTYqOrdlckOYuMcmX7t3x1R2M%3D&ftpl=1&idc=maliva&ps=13740610&s=AWEME_DETAIL&shcp=34ff8df6&shp=d05b14bd&t=4d5b0474",
    "duration": 12,
    "play": "https://v16m-default.akamaized.net/ffcb986a160a88c5b4ac91488599a33d/66ffbbe9/video/tos/useast2a/tos-useast2a-ve-0068c001-euttp/os0O7iBRPBmbepErVQBsAFzrIftKV1Di5uEwiQ/?a=0&bti=OUBzOTg7QGo6OjZAL3AjLTAzYCMxNDNg&ch=0&cr=0&dr=0&er=0&lr=all&net=0&cd=0%7C0%7C0%7C0&cv=1&br=2392&bt=1196&cs=0&ds=6&ft=XE5bCqT0majPD12y1Hp73wUOx5EcMeF~O5&mime_type=video_mp4&qs=0&rc=MzplO2c2MzNoPDk7ZTVoaUBpM2c5dXU5cjg4dTMzZjczM0A0YWFfM15fXi0xNC0vYWItYSM0azJeMmRjX25gLS1kMWNzcw%3D%3D&vvpl=1&l=202410040356447D5C8A7C1BA0947305EF&btag=e00088000",
    "wmplay": "https://v16m-default.akamaized.net/996efa6e61ba727e31129029177fb5e7/66ffbbe9/video/tos/useast2a/tos-useast2a-ve-0068c001-euttp/ogmHIGALugWtvjAgWeI60sRKW4krGeREe1eNyS/?a=0&bti=OUBzOTg7QGo6OjZAL3AjLTAzYCMxNDNg&ch=0&cr=0&dr=0&er=0&lr=all&net=0&cd=0%7C0%7C0%7C0&cv=1&br=2502&bt=1251&cs=0&ds=3&ft=XE5bCqT0majPD12y1Hp73wUOx5EcMeF~O5&mime_type=video_mp4&qs=0&rc=PGRoOjs0Nzw6PDhmOjNoPEBpM2c5dXU5cjg4dTMzZjczM0AuMWBgNS42NS4xNC5gMzFeYSM0azJeMmRjX25gLS1kMWNzcw%3D%3D&vvpl=1&l=202410040356447D5C8A7C1BA0947305EF&btag=e00088000",
    "hdplay": "https://v16m-default.akamaized.net/4166d02e1b4cc39f7792c7a402214433/66ffbbe9/video/tos/useast2a/tos-useast2a-v-0068c001-euttp/ocZikBeHEAPKVtAE7DVi6rrAVEDRQAipm0BsOf/?a=0&bti=OUBzOTg7QGo6OjZAL3AjLTAzYCMxNDNg&ch=0&cr=0&dr=0&er=0&lr=all&net=0&cd=0%7C0%7C0%7C1&cv=1&br=13810&bt=6905&ds=4&ft=XE5bCqT0majPD12y1Hp73wUOx5EcMeF~O5&mime_type=video_mp4&qs=13&rc=M2c5dXU5cjg4dTMzZjczM0BpM2c5dXU5cjg4dTMzZjczM0A0azJeMmRjX25gLS1kMWNzYSM0azJeMmRjX25gLS1kMWNzcw%3D%3D&vvpl=1&l=202410040356443E82B95D2733BD702AAE&btag=e00048000",
    "size": 1841459,
    "wm_size": 1927263,
    "hd_size": 10672874,
    "music": "https://sf16-ies-music.tiktokcdn.com/obj/ies-music-euttp/7418650383914552096.mp3",
    "music_info": {
      "id": "7418650378251586336",
      "title": "original sound - nikolaisavic",
      "play": "https://sf16-ies-music.tiktokcdn.com/obj/ies-music-euttp/7418650383914552096.mp3",
      "cover": "https://p16-sign-useast2a.tiktokcdn.com/tos-useast2a-avt-0068-euttp/83de9a7f80735844531556fe72a37b24~tplv-tiktokx-cropcenter:1080:1080.jpeg?dr=14579&nonce=62796&refresh_token=c6a81cf7147b9c7a324a088b23f9e54e&x-expires=1728097200&x-signature=XeoGBl6dScLLEPSzAQanrYH8r2g%3D&idc=maliva&ps=13740610&shcp=d05b14bd&shp=45126217&t=4d5b0474",
      "author": "Nikolai Savic",
      "original": true,
      "duration": 12,
      "album": ""
    },
    "play_count": 11906408,
    "digg_count": 1167345,
    "comment_count": 13238,
    "share_count": 24957,
    "download_count": 10717,
    "collect_count": 42968,
    "create_time": 1727289144,
    "anchors": null,
    "anchors_extras": "",
    "is_ad": false,
    "commerce_info": {
      "adv_promotable": false,
      "auction_ad_invited": false,
      "bc_label_test_text": "Paid partnership",
      "branded_content_type": 1,
      "with_comment_filter_words": false
    },
    "commercial_video_info": "",
    "item_comment_settings": 0,
    "mentioned_users": "",
    "author": {
      "id": "6679867017149252613",
      "unique_id": "nikolaisavic",
      "nickname": "Nikolai Savic",
      "avatar": "https://p16-sign-useast2a.tiktokcdn.com/tos-useast2a-avt-0068-euttp/83de9a7f80735844531556fe72a37b24~tplv-tiktokx-cropcenter:300:300.jpeg?dr=14577&nonce=87578&refresh_token=6717b6d3c3ddca4f6c5c4f0a12ca0696&x-expires=1728097200&x-signature=hRW2no8BUSc%2Ff5%2BYa06qvFCVob0%3D&idc=maliva&ps=13740610&shcp=d05b14bd&shp=45126217&t=4d5b0474"
    }
  }
}*/
//===================🥂==========🥂=============

/*cmd({
    pattern: "tiktok",
    alias: ["tiktokwwm"],
    desc: "Download tiktok videos",
    category: "downloaddd",
    use: '.tiktoknowm <tiktok link>',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if (!q) return await  reply('tiktok') 
let data = await tiktokdl(q)

let desc = `
😒 *MANTHILA TIKTOK DL* 😒

Title: ${data.data.title}
Country: ${data.data.region}
Duration : ${data.data.duration}
Account: ${data.data.author.nickname}
> --------------------------------------------

- Views: ${data.data.play_count}
- Comment: ${data.data.comment_count}
- Share: ${data.data.share_count}
- Download: ${data.data.download_count}
- Creted time: ${data.data.create_time}
`

//return reply(desc)
await conn.sendMessage(from,{image:{url:data.data.cover},caption:desc},{quoted:mek})
await sleep(1000)   
await conn.sendMessage(from, { video: { url: data.data.play }, caption: "> NO-WATERMARK",}, { quoted: mek })
await conn.sendMessage(from, { video: { url: data.data.wmplay }, caption: "> WITH-WATERMARK",}, { quoted: mek })
await conn.sendMessage(from,{document: {url:data.data.music},mimetype:"audio/mpeg",fileName: data.data.title, caption:"POWERED BY DARK-YASH-MD"},{quoted:mek})
  //await conn.sendMessage(from, { video: { url: data.data.hdplay }, caption: "> HD-QUALITY",}, { quoted: mek })
return await conn.sendMessage(from, { audio: { url: data.data.music },mimetype:"audio/mpeg"}, { quoted: mek })
//await conn.sendMessage(from,{document: {url:data.data.music},mimetype:"audio/mpeg",fileName: data.data.title},{caption:"POWERED BY DARK-YASH-MD"},{quoted:mek})
//let audttdoc = await conn.sendMessage(from, { document: { url: music }, caption: cap,mimetype:"audio/mpeg",fileName:"TikTok Audio.mp3"}, { quoted: mek });

//return await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
} catch (e) {
//reply(`${e}`)
l(e)
}
})*/


  

/*const { tiktokdl } = require('tiktokdl')
const config = require('../config')
const { cmd, commands } = require('../command')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')
var monspace ='```'

//===============TIKTOK VIDEO DL CMD===============
cmd({
    pattern: "tiktok2",
    alias: ["ttwm"],
    desc: "Download tiktok videos",
    category: "download",
    use: '.tiktok <tiktok link>',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
await conn.sendMessage(from, { react: { text: '💥', key: mek.key }})
if(!q) return await conn.sendMessage(from , { text: '*⚠️ Please give me tiktok url dear‼️*' }, { quoted: mek } )
//if (!q) return await  reply('*⚠️ Please give me tiktok url dear‼️*')

let wm = `> *THIS VIDEO DOES NOT INCLUDE TIKTOK WATERMARK...*\n\n● *ᴅᴀʀᴋ ʏᴀꜱʜ ᴍᴅ ʙʏ ᴍᴀɴɪ* ●`
let wmtwo = `> *THIS VIDEO INCLUDE TIKTOK WATERMARK...*\n\n● *ᴅᴀʀᴋ ʏᴀꜱʜ ᴍᴅ ʙʏ ᴍᴀɴɪ* ●`
let cap = `● *ᴅᴀʀᴋ ʏᴀꜱʜ ᴍᴅ ʙʏ ᴍᴀɴɪ* ●`

let response = await tiktokdl(q)
let { video } = response
let { music } = response

let ttcp = `*┠─❲ 🧛 DARK-YASH-MD 🧛 ❳─┨*

    *🧧  TIKTOK DOWNLOADER 🧧*

*┌───────────────────┐*
┝ *➤ \`Title :\` * ${response.data.author}
┝ *➤ \`Region:\` * Coming Soon
┝ *➤ \`Duration:\` * Coming Soon
┝ *➤ \`Views:\` * Coming Soon
┝ *➤ \`Url:\` * Coming Soon 
*└───────────────────┘*

🔢 *Please reply with the number you want to select:*

*1.* Tiktok Video
   1.1 | 🎟️ With-Watermark
   1.2 | 📼 No-Watermark

*2.* Tiktok Audio
   2.1 | 🎶 Audio file
   2.2 | 📁 Document file
   2.3 | 🎤 Voice cut [ptt]

*🖇️ URL:* ${q}
`
clean(response.data.author
let response = await tiktokdl(q)
let { video } = response
let { music } = response

//==========NON BUTTON MSG SEND==========

const sentMsg = await conn.sendMessage(from,  { image: { url: 'https://telegra.ph/file/8932f8350240ebb87c4ee.jpg' }, caption: ttcp }, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference

// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1.1', '1.2', '2.1', '2.2' , '2.3'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

if (messageType === '1.1') {
// Handle option 2 (Tiktok Video No Watermark)
let nowm = await conn.sendMessage(from, { video: { url: video }, caption: wm }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: nowm.key } });

} else if (messageType === '1.2') {
// Handle option 4 (Tiktok Video No Watermark as Document)
let nowmdoc = await conn.sendMessage(from, { document: { url: video }, mimetype: 'video/mp4', fileName: 'TikTok_No_Watermark.mp4', caption: wm }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: nowmdoc.key } });

} else if (messageType === '2.1') {
// Handle option 5 (Tiktok Audio File)
//await conn.sendMessage(from, { audio: { url: data[text] }, mimetype: 'audio/mpeg', ptt: true }, { quoted: mek });
let audtt = await conn.sendMessage(from, { audio: { url: music },mimetype:"audio/mpeg"}, { quoted: mek });
//let audtt = await conn.sendMessage(from, { audio: { url: music }, mimetype: 'audio/mpeg', { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎶', key: audtt.key } });

} else if (messageType === '2.2') {
// Handle option 6 (Tiktok Document File)
let audttdoc = await conn.sendMessage(from, { document: { url: music }, caption: cap,mimetype:"audio/mpeg",fileName:"TikTok Audio.mp3"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎶', key: audttdoc.key } });

} else if (messageType === '2.3') {
// Handle option 5 (Tiktok Audio File)
//await conn.sendMessage(from, { audio: { url: data[text] }, mimetype: 'audio/mpeg', ptt: true }, { quoted: mek });
let audtt = await conn.sendMessage(from, { audio: { url: music }, mimetype: 'audio/mpeg', ptt: true }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎶', key: audtt.key } });

}
} else {
// React with invalid input
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1.1-1.2 , 2.1-2.3) ‼️*' }, { quoted: mek });
}    
}
});

} catch (e) {
console (e)
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
}
})/*
//============================== CMD END ==============================



    
//===============TIKTOK AUDIO DL CMD===============

/*cmd({
    pattern: "ttimg",
    react: '💫',
    desc: "Download tiktok audios",
    category: "download",
    use: '.ttimg <tiktok link>',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
  if (!q) return await  reply('*Please give me tiktok url !!*')
let wm = '*`✦ TIKTOK DOWNLODER ✦`*\n\n⦁ ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ⦁' 
let wwm = 'blackfire'
let response = await tiktokdl(q)

let { image } = response
//await conn.sendMessage(from, { video: { url: video }, caption: wm,}, { quoted: mek })
await conn.sendMessage(from, { image: { url: image }, caption: "*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙy ᴍᴀɴɪ ⦁*" }, { quoted: mek });
//let tt = await conn.sendMessage(from, { audio: { url: music }, caption: wm,mimetype:"audio/mpeg"}, { quoted: mek })
//return await conn.sendMessage(from, { react: { text: '🎧', key: tt.key }})
//return await conn.sendMessage(from, { react: { text: '✅', key: mek.key }})

} catch (e) {
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
l(e)
}
})*/
//==============================CMD END==============================





//===============TIKTOK DOCUMENT DL CMD===============
/*cmd({
    pattern: "tiktokdoc",
    react: '💫',
    desc: "Download tiktok document",
    category: "downloaddd",
    use: '.tiktokdocument <tiktok link>',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if (!q) return await  reply('*Please give me tiktok url !!*')
let wm = '● *ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ* ●' 
let wwm = 'blackfire'
let response = await tiktokdl(q)

let { music } = response
//await conn.sendMessage(from, { video: { url: video }, caption: wm,}, { quoted: mek })
await conn.sendMessage(from, { document: { url: music }, caption: wm,mimetype:"audio/mpeg",fileName:"Tik Tok Audio.mp3"}, { quoted: mek })
return await conn.sendMessage(from, { react: { text: '🎧', key: wm.key }})
return await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
} catch (e) {
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
l(e)
}
})*/
//==============================CMD END==============================

                              



/*cmd({
    pattern: "tiktoknowm",
    alias: ["tiktokwwm"],
    react: '✨',
    desc: "Download tiktok videos",
    category: "downloaddd",
    use: '.tiktoknowm <tiktok link>',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
  if (!q) return await  reply('*Please give me tiktok url !!*')
let nowm = '\n⦁ ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ⦁' 
let response = await tiktokdl(q)
let { video } = response
let { music } = response
await conn.sendMessage(from, { video: { url: video }, caption: nowm,}, { quoted: mek })
//await conn.sendMessage(from, { audio: { url: music }, caption: wm,mimetype:"audio/mpeg"}, { quoted: mek })
return await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
} catch (e) {
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
l(e)
}
})*/


//==============================DARK-YASH  MD CORDS (CREATED BY M.G.MANTHILA)==============================
