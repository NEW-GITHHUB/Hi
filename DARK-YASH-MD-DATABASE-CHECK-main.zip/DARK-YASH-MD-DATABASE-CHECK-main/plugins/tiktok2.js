const {readEnv} = require('../lib/database')
const fs = require('fs')
const { fetchJson } = require('../lib/functions')
const { cmd, commands } = require('../command')

let baseUrl;
(async () => {
let baseUrlGet = await fetchJson(`https://raw.githubusercontent.com/prabathLK/PUBLIC-URL-HOST-DB/main/public/url.json`)
baseUrl = baseUrlGet.api
})();

const yourName = "*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*";

cmd({
    pattern: "tiktok2",
    alias: ["tt"],
    desc: "download tt videos",
    category: "download",
    filename: __filename
},
async(conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()
   
if (!q && !q.startsWith("https://")) return reply("give me tiktok url")
let data = await fetchJson(`${baseUrl}/api/tiktokdl?url=${q}`)
let ttcp = `*┠─❲ 🧛 DARK-YASH-MD 🧛 ❳─┨*

    *🧧  TIKTOK DOWNLOADER 🧧*

*┌───────────────────┐*
┝ *➤ \`Title :\`* Coming soon
┝ *➤ \`Region:\`* Coming Soon
┝ *➤ \`Duration:\`* Coming Soon
┝ *➤ \`Views:\`* Coming Soon
┝ *➤ \`Url:\`* Coming Soon 
*└───────────────────┘*

🔢 *Please reply with the number you want to select:*

*[1] Tiktok Video*
    1.1 | 🎟️ With-Watermark
    1.2 | 📼 No-Watermark

*[2] Tiktok Audio*
    2.1 | 🎶 Audio file
    2.2 | 📁 Document file
    2.3 | 🎤 Voice cut [ptt]

*🖇️ URL:* ${q}

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙy ᴍᴀɴɪ ⦁*
`

//==========NON BUTTON MSG SEND==========

const sentMsg = await conn.sendMessage(from,  { image: { url: 'https://telegra.ph/file/8932f8350240ebb87c4ee.jpg' }, caption: ttcp }, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference

// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

//-----------------------Non Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

    
// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1.1', '1.2', '2.1' , '2.2', '2.3'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

if (messageType === '1.1') {
// Handle option 2 (Tiktok Video No Watermark)
let nowm = await conn.sendMessage(from, { video: { url: data.data.wm }, mimetype: "video/mp4", caption: `- WITH-WATERMARK\n\n ${yourName}` }, { quoted: mek })
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: nowm.key } });

} else if (messageType === '1.2') {
// Handle option 4 (Tiktok Video With Watermark)
let nowm = await conn.sendMessage(from, { video: { url: data.data.no_wm }, mimetype: "video/mp4", caption: `- NO-WATERMARK \n\n ${yourName}` }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: nowm.key } });

} else if (messageType === '2.1') {
// Handle option 5 (Tiktok Audio File)
let audtt = await conn.sendMessage(from, { audio: { url: data.data.audio }, mimetype: "audio/mpeg" }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎶', key: audtt.key } });

} else if (messageType === '2.2') {
// Handle option 5 (Tiktok Audio File)
let audtt = await conn.sendMessage(from, { audio: { url: data.data.audio }, mimetype: "audio/mpeg" }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎶', key: audtt.key } });

} else if (messageType === '2.3') {
// Handle option 5 (Tiktok Audio File)
await conn.sendMessage(from, { audio: { url: data.data.audio }, mimetype: "audio/mpeg", ptt: true }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
//await conn.sendMessage(from, { react: { text: '🎶', key: audtt.key } });
}

} else {
// React with invalid input
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1.1-1.2 , 2.1-2.3) ‼️*' }, { quoted: mek });
}    
}
});

} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
})
