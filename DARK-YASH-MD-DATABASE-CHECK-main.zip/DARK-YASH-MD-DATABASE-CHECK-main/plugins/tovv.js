const {cmd , commands} = require('../command')

cmd({
    pattern: "tovv",
    desc: "image/video to view once",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(m.quoted && m.quoted.type === "imageMessage"){
let cap = m.quoted.imageMessage.caption || q || "null"
let data = await m.quoted.download()
const del = await conn.sendMessage(m.chat, { text: `*Converting...*` }, { quoted: mek });
await conn.sendMessage(from, { image: data, caption: cap,viewOnce:true });
return await conn.sendMessage(m.chat, { delete: del });
}else if(m.quoted && m.quoted.type === "videoMessage"){
const del = await conn.sendMessage(m.chat, { text: `*Converting...*` }, { quoted: mek });
let cap = m.quoted.videoMessage.caption || q || "⦁ ᴘʀᴀʙᴀᴛʜ-ᴍᴅ ⦁"
let data = await m.quoted.download()
await conn.sendMessage(from, { video: data, caption: cap,viewOnce:true });	
return await conn.sendMessage(m.chat, { delete: del });
}else if(m.quoted && m.quoted.type === "audioMessage"){
const del = await conn.sendMessage(m.chat, { text: `*Converting...*` }, { quoted: mek });
let data = await m.quoted.download()
conn.sendMessage(from, { audio:  data, mimetype: 'audio/mpeg', ptt: true, viewOnce:true, fileName: `${m.id}.mp3` })
return await conn.sendMessage(m.chat, { delete: del });
}else{
reply("*give me image/video/audio Message*")
}	
}catch(e){
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
})
