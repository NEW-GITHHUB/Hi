const { cmd } = require('../command');

cmd({
    pattern: "forward",
    desc: "forward msgs",
    category: "owner",
    use: '.send < Jid address >',
    filename: __filename
},

async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {

await conn.sendMessage(from, { react: { text: '↪️', key: mek.key } });
if (!isOwner) {
const rce = await conn.sendMessage(from,{text:"*⛔ THIS IS AN OWNER COMMAND*"},{quoted:mek})
const reactionMessage = {react: {text: "⛔", key: rce.key }}
return await conn.sendMessage(from, reactionMessage)
}
if (!m.quoted) {
const rc = await conn.sendMessage(from,{text:"*❌ Please mention a message to forward*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
if (!q) {
const rcd = await conn.sendMessage(from,{text:"❌ *Please Give me a Jid Addres*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rcd.key }}
return await conn.sendMessage(from, reactionMessage)
}

let message = {};
message.key = mek.quoted.fakeObj.key;

if (mek.quoted.documentWithCaptionMessage?.message?.documentMessage) {
let mime = mek.quoted.documentWithCaptionMessage.message.documentMessage.mimetype;
const mimeType = require('mime-types');
let ext = mimeType.extension(mime);
mek.quoted.documentWithCaptionMessage.message.documentMessage.fileName = mek.quoted.documentWithCaptionMessage.message.documentMessage.caption + "." + ext;
}

message.message = mek.quoted;
const jids = q.split(',').map(jid => jid.trim());

for (let jidss of jids) {
await conn.forwardMessage(jidss, message, true);
}
return reply(`*↔️ Message forwarded to:*\n\n ${jids.join(', ')}\n`);

} catch (e) {
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
console.log(e);
reply(`🛑 *DARK YASH MD ERRO`)
}
});
