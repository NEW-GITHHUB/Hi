const { cmd, commands } = require('../command');
const fbDownloader = require('fb-downloader-scrapper'); // Use fb-downloader-scrapper package

//===========================BLACK FIRE FB DOWNLOAD CMD=========================== 

cmd({
    pattern: "fb",
    desc: "Download Facebook videos and audios",
    category: "download",
    filename: __filename

},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {
await conn.sendMessage(from, { react: { text: '🔰', key: mek.key }})
if(!q) return await conn.sendMessage(from , { text: '⚠️ *Please give me a facebook url dear*‼️' }, { quoted: mek } )
//if (!q) return reply("⚠️ *Please provide a Facebook video URL or title*‼️");
        
// Download Facebook video
const fbData = await fbDownloader(q);
const videoHdUrl = fbData.hd || null; // Extract HD video URL
const videoSdUrl = fbData.sd || null; // Extract SD video URL
const audioUrl = fbData.audio || null; // Extract Audio URL if available
const thumbnailUrl = fbData.thumbnail || null;

if (!videoHdUrl && !videoSdUrl) {
return reply("⚠️ *Could not retrieve video from the provided URL*‼️");
}

let desc = `*┠─❲ 🧛 DARK-YASH-MD 🧛 ❳─┨*

    *🧨 FB DOWNLOADER 🧨*

*📚 \`Title:\`* ${fbData.title} || "Facebook Video"}

🔢 Please reply the number you want to select

*\`[1] facebook Noramal Video  🎥\`*
       1.1 | 🪫 SD QUALITY
       1.2 | 🔋 HD QUALITY

*\`[1] facebook Video Document 📂\`*
       2.1 | SD QUALITY 📂
       2.2 | HD QUALITY 📂

*\`[2] facebook Video Audio 🎶\`*
       3.1 | Audio file 🎶
       3.2 | Document file 📂


*🖇️ FB URL:* ${q}

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙy ᴍᴀɴɪ ᴏꜰᴄ ⦁*
`;

// Send the message with options
const sentMsg = await conn.sendMessage(from,  { image: { url: thumbnailUrl }, caption: desc }, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference
//await conn.sendMessage(from, { react: { text: '🔢', key: sentMsg.key } });
// Invalid option
// Listen for user response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1.1', '1.2', '2.1', '2.2', '3.1', '3.2'].includes(messageType)) {
// React to download
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
// React to upload
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

// Process user response and send the corresponding file

if (messageType === '1.2' && videoHdUrl) {
// 1️⃣ HD Video File
let hd = await conn.sendMessage(from, { video: { url: videoHdUrl }, caption: "< *HD Quality*\n\n● *ᴅᴀʀᴋ ʏᴀꜱʜ ᴍᴅ ʙʏ ʜᴅꜱ* ●" }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '📽️', key: hd.key } });

} else if (messageType === '1.1' && videoSdUrl) {
// 2️⃣ SD Video File
let sd = await conn.sendMessage(from, { video: { url: videoSdUrl }, caption: "< *SD Quality*\n\n● *ᴅᴀʀᴋ ʏᴀꜱʜ ᴍᴅ ʙʏ ʜᴅꜱ* ●" }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: sd.key } });

} else if (messageType === '2.2' && videoHdUrl) {
// 3️⃣ HD Video as Document
let hddoc = await conn.sendMessage(from, { document: { url: videoHdUrl }, mimetype: "video/mp4", fileName: fbData.title + "-HD.mp4", caption: "< *HD Quality*\n\n● *ᴅᴀʀᴋ ʏᴀꜱʜ ᴍᴅ ʙʏ ʜᴅꜱ* ●" }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: hddoc.key } });

} else if (messageType === '2.1' && videoSdUrl) {
// 4️⃣ SD Video as Document
let sddoc = await conn.sendMessage(from, { document: { url: videoSdUrl }, mimetype: "video/mp4", fileName: fbData.title + "-SD.mp4", caption: "< *SD Quality*\n\n● *ᴅᴀʀᴋ ʏᴀꜱʜ  ᴍᴅ ʙʏ ʜᴅꜱ* ●" }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: sddoc.key } });

} else if (messageType === '3.1' && audioUrl) {
// 5️⃣ Audio as File
let fbaud = await conn.sendMessage(from, { audio: { url: audioUrl }, mimetype: "audio/mpeg" }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎧', key: fbaud.key } });

} else if (messageType === '3.2' && audioUrl) {
// 6️⃣ Audio as Document
let fbauddoc = await conn.sendMessage(from, { document: { url: audioUrl }, mimetype: "audio/mpeg", fileName: fbData.title + ".mp3", caption: "● *ʙʟᴀᴄᴋ ꜰɪʀᴇ ᴍᴅ ʙʏ ʜᴅꜱ* ●" }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
await conn.sendMessage(from, { react: { text: '📂', key: fbauddoc.key } });
}
} else {
// React with invalid input
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
let df = await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1.1-1.2 , 2.1-2.2 , 3.1-3.3) ‼️*' }, { quoted: mek });
//await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1.1-1.2 , 2.1-2.2 , 3.1-3.3) ‼️*' }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❓', key: df.key } });

}
}
});
    
} catch (e) {
console.log(e);
reply(`⚠️ *DARK YASH MD Error➤*‼️ ${e}`);
}
});                    
