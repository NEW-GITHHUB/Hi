const {readEnv} = require('../lib/database')
const { fetchJson } = require('../lib/functions')
const {cmd , commands} = require('../command')
const fs = require('fs')
const apkdl = require('../lib/apkdl')

cmd({
    pattern: "apk",
    dontAddCommandList: true,
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()
const config = await readEnv();

await conn.sendMessage(from, { react: { text: '🗃️', key: mek.key }})
if(!q) return await conn.sendMessage(from , { text: 'Need apk link...' }, { quoted: mek } ) 
const data = await apkdl.download(q)
let listdata = `⚆⚯───────────────────────⚯⚆
*🗃️ DARK YASH APK DOWNLOADER 🗃️*
⚆⚯───────────────────────⚯⚆

┏━━━━━━━━━━━━━━━━━━━━━━━━━┓
├ 📚 *\`Name :\`* ${data.name}
├ 🤴 *\`Developer :\`*  ${data.package}
├ ♻️ *\`Last update :\`* ${data.lastup}
├ 🔗 *\`Url :\`* ${data.dllink}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛

*1 | DOWNLOADED APK 📦*

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*`

//============================================================================================================
const sentMsg = await conn.sendMessage(from, {image:{url: data.icon}, caption: listdata }, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference
//============================================================================================================

// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;

//-----------------------Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

    
// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

//============================================================================================================ 
if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

//============================================================================================================
if (messageType === '1') {
// Handle option 1 (Audio File)
let reactapk = await conn.sendMessage(from , { document : { url : data.dllink } , mimetype : 'application/vnd.android.package-archive' , fileName : data.name + '.' + 'apk',caption: '● *ᴅᴀʀᴋ ʏᴀꜱʜ ᴍᴅ ʙʏ ᴍᴀɴɪ* ●' } , { quoted: mek });
// React with file upload completes
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
//react apk
await conn.sendMessage(from, { react: { text: '📦', key: reactapk.key }});
} else {

// React with invalid inpuet
await conn.sendMessage(from,{ react: { text: '❌', key: mk.key } });
// Invalid option
let df = await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1) ‼️*' }, { quoted: mek });
await conn.sendMessage(from,{ react: { text: '❗', key: df.key } });

}
} 
}
}); 
// React to the successful completion of the task

} catch (e) {
console.log(e);
reply(`⚠️ *DARK YASH MD Error➤*‼️ ${e}`)
}
});
