const {readEnv} = require('../lib/database')
const fs = require('fs')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')
const Esana = require('@sl-code-lords/esana-news');
var api = new Esana()
const {cmd,  commands} = require('../command')

const apilink = 'https://dark-yasiya-news-apis.vercel.app/api' // API LINK ( DO NOT CHANGE THIS!! )


cmd({
    pattern: "news",
    desc: "To see esana news",
    category: "search",
    use: '.news',
    filename: __filename
},
async(conn, mek, m,{from, l, prefix, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()

const data = await fetchJson('https://app-97e3fc0d-9aec-4ff1-a518-b7b72a127d7c.cleverapps.io/api/latest')

const newes = await fetchJson(`${apilink}/sirasa`)
const news = await fetchJson(`${apilink}/derana`)
    
const latst = await api.latest_id();
const nws = latst.results.news_id 
let nn = q || nws
const ress = await api.news(nn);
const res = ress.results;


//======================================CMD END===================================

let dess = `🗞️ *DARK YASH NEWS CENTER (24 HOURS)* 📡

*⛬ ➜ Select the type of news you want and mention this message and reply to the relevant number...*

- 1 | *ESANA NEWS* [Last news]

- 2 | *HIRU NEWS* [Last news]

- 3 | *DERANA NEWS* [Last news]

- 4 | *SIRASA NEWS* [Last news]

 *⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙy ᴍᴀɴɪ ⦁*
`
//======================================ESANA-NEWS======================================

let desc = `*┠─❲ 🧙‍♂️ DARK-YASH ESANA NEWS ❳*
    
*┃◉* *⇨ 🕯️ ᴛɪᴛʟᴇ :*
   *${res.TITLE}*

*┃◉* *⇨ ⏰ ᴘᴜʙʟɪꜱʜᴇᴅ ᴅᴀᴛᴇ :*
   ${res.PUBLISHED}

*┃◉* *⇨ 🖇️ ᴜʀʟ :*
   ${res.URL}

*┃◉* *⇨ 📚 ᴅᴇꜱᴄʀɪᴘᴛɪᴏɴ :*
   ${res.DESCRIPTION}

> ◉ ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ*
`;

    
//======================================HIRU-NEWS===================================
let info = `*┠─❲ 🧙‍♂️ DARK-YASH HIRU NEWS ❳*
    
*┃◉* *⇨ 🕯️ ᴛɪᴛʟᴇ :*
     *${data.title}*

*┃◉* *⇨ ⏰ ᴘᴜʙʟɪꜱʜᴇᴅ ᴅᴀᴛᴇ :*
     ${data.time}

*┃◉* *⇨ 📚 ᴅᴇꜱᴄʀɪᴘᴛɪᴏɴ :*
     ${data.desc}

> ◉ ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ`


//======================================CMD END===================================
let msg = `
           🔺 *SIRASA NEWS* 🔺

       
• *Title* - ${newes.result.title}

• *News* - ${newes.result.desc}

• *Link* - ${newes.result.url}`


let msggg = `
           📑 *DERANA NEWS* 📑

       
• *Title* - ${news.result.title}

• *News* - ${news.result.desc}

• *Date* - ${news.result.date}

• *Link* - ${news.result.url} `



//=========================================================================((===========================
const sentMsg = await conn.sendMessage(from ,{ text: dess }, {quoted:mek});
const messageID = sentMsg.key.id; // Save the message ID for later reference
//=========================================================================((===========================

    
//=========================================================================((===========================
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;
//======================================================================================================

//-----------------------Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

//=========================================================================(==========================  
// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;
//=========================================================================((===========================

    
//=========================================================================((===========================   
if (isReplyToSentMsg) {

if (['1', '2', '3','4'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '🆗', key: mek.key } });
//=========================================================================((===========================
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
}, 3000);
//=========================================================================((===========================

//=========================================================================((===========================
if (messageType === '1') {
// Handle option 1 (Audio File)
let aud = await conn.sendMessage(from,{image:{url: res.COVER},caption: desc },{quoted:mek});
// React with file upload completes
//await conn.sendMessage(from, { react: { text: '✔', key: mek.key } });
//aud send react
await conn.sendMessage(from, { react: { text: '🗞️', key: aud.key }});
//=========================================================================((===========================

} else if (messageType === '2') {
// Handle option 2 (Document File)
let doc = await conn.sendMessage(from,{image:{url: data.image },caption: info },{quoted:mek});
// React with file upload completes
//await conn.sendMessage(from, { react: { text: '✔', key: mek.key } });
//aud doc react send
await conn.sendMessage(from, { react: { text: '🗞️', key: doc.key }});
//=========================================================================((===========================

} else if (messageType === '3') {
// Handle option 2 (Document File)
let dera = await conn.sendMessage( from, { image: { url: news.result.image }, caption: msggg }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '🗞️', key: dera.key }});
//=========================================================================((===========================

} else if (messageType === '4') {
// Handle option 2 (Document File)
let df = await conn.sendMessage( from, { image: { url: newes.result.image }, caption: msg }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '🗞️', key: doc.key }});
//=========================================================================((===========================

}
}
}
});

}catch(e){
console.log(e)
reply(`⚠️ *Dark Yash MD Error➤*‼️ ${e}`)
}
})




/*cmd({
    pattern: "hiru2",
    alias: ["hnews","hirunews"],
    react: "🍎",
    desc: "It gives hiru news.",
    category: "search",
    use: '.hnews',
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{

const scrape = await fetchJson('https://sinhala.newsfirst.lk/latest-news');
let info = `*📃 Title :* ${scrape.title}

*📚 Description:* ${scrape.desc}
`
return await conn.sendMessage(from, { image: { url: scrape.img} , caption: info } , { quoted: mek })
//await conn.sendMessage(m.chat, {  react: {  text: "🗞️",   key: enews.key }})

}catch(e){
console.log(e)
reply(`⚠️ *Dark Yash MD Error➤*‼️ ${e}`)
}
})*/
