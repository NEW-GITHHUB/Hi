const config = require('../config')
const {cmd , commands} = require('../command')
const { fetchJson } = require('../lib/functions')
const fs = require('fs')

cmd({
    pattern: "toaudio",
    desc: "tado",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{

await conn.sendMessage(from, { react: { text: '🎤', key: mek.key } });

if(!m.quoted && !m.mentionJid) {
const rc = await conn.sendMessage(from,{text:"❌ *Please Give me a Video or Voice Message.*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
const fileDataMB = "30";

if (mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage?.fileLength) {
const fileLengthBytes = mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.fileLength;
const fileLengthMB = fileLengthBytes / (1024 * 1024);

if (fileLengthMB > fileDataMB) return reply(`❌ *Cannot fetch videos longer than ${fileDataMB}MB*`);
}
if (mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.audioMessage?.fileLength) {
const fileLengthBytes = mek.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage.fileLength;
const fileLengthMB = fileLengthBytes / (1024 * 1024);

if (fileLengthMB > fileDataMB) return reply(`❌ *Cannot fetch audios longer than ${fileDataMB}MB*`);
}
if (mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.documentMessage?.fileLength) {
const fileLengthBytes = mek.message.extendedTextMessage.contextInfo.quotedMessage.documentMessage.fileLength;
const fileLengthMB = fileLengthBytes / (1024 * 1024);

if (fileLengthMB > fileDataMB) return reply(`❌ *Cannot fetch audios longer than ${fileDataMB}MB*`);
}

if (!(m.quoted.type === "audioMessage" || m.quoted.type === "videoMessage" || m.quoted.type === "documentMessage")) {
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
return await conn.sendMessage(from, { text: '⛔ *Cannot convert this message type.*' }, { quoted: mek });
}

if(m.quoted.type === "audioMessage" || m.quoted.type === "videoMessage" || m.quoted.type === "documentMessage") {

var nameJpg = m.id;

const mass = await conn.sendMessage(from, { text: "*♻️ Converting and Uploading your File...*" }, { quoted: mek });  
let buff = await m.quoted.download(nameJpg)
let fileType = require('file-type');
let type = fileType.fromBuffer(buff);
await fs.promises.writeFile("./" + type.ext, buff);

let sendaudio = await conn.sendMessage(m.chat, { audio: fs.readFileSync("./" + type.ext), mimetype:  'audio/mpeg',ptt: true,fileName: `${m.id}.mp3` },{quoted: mek})
//await conn.sendMessage(m.chat, { delete: mass })
await conn.sendMessage(m.chat, { react: { text: '✅', key: mass.key } });
await conn.sendMessage(from, { react: { text: '🎙️', key: sendaudio.key } });
}       

}catch(e){
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
});
