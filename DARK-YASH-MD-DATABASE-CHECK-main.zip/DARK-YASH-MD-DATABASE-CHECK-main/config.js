const fs = require('fs');
if (fs.existsSync('config.env')) require('dotenv').config({ path: './config.env' });
function convertToBool(text, fault = 'true') {
    return text === fault ? true : false;
}
module.exports = {
SESSION_ID: process.env.SESSION_ID === undefined ? ' ' : process.env.SESSION_ID,
BTN_BASE: "Follow Channel",
OWNER: process.env.OWNER === undefined ? `94742614390` : process.env.OWNER,
BTN_BASE_URL: "https://whatsapp.com/channel/0029VadeSsrEAKWC5XDIba42",
MAX_SIZE: 200,
MONGODB: process.env.MONGODB || "mongodb+srv://gihindunew2k24:Chanuvaaa12345@cluster0.42ydw.mongodb.net/"
};
