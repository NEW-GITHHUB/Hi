# MANI-NEWS-BOT

# **`🌟HELLO I AM MANI OFFICIAL NEWS BOT🌟`**


<br>

<p align="center">  
  <a href="https://telegra.ph/file/f906adb24632937e98a40.jpg">
    <img alt="-MANI-NEWS-BOT" height="300" src="https://telegra.ph/file/f906adb24632937e98a40.jpg">
    


<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=HELLO+IAM+MANI+OFFICIAL+NEWS+BOT" alt="">
</p>


💫 `NEWS BOT CREATED BY GIHINDU MANTHILA (MANI TEAM OWNER)`



<br>

## `LOGIN WITH WHATSAPP` 👇

<a href="https://mani-ofc-pair-code-2024-a39dd47dc981.herokuapp.com/"><img src="https://img.shields.io/badge/LOGIN%20WITH-PAIR%20CODE-Yellow" alt="LOGIN WITH PAIR CODE" width="250"></a>

<a href="https://prabath--md-official.vercel.app/"><img src="https://img.shields.io/badge/LOGIN%20WITH-QR%20CODE-blue" alt="LOGIN WITH QR CODE" width="250"></a>
<br>


<br>

## **`DEPLOYMENT METHODS 👇`**

[![Deploy on heroku](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?button-url=https://github.com/MANTHILA-LK-2K24/MANI-NEWS-BOT-2K24&template=https://github.com/MANTHILA-LK-2K24/MANI-NEWS-BOT-2K24.git)


[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/5_3enq)


[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/apps/deploy?type=git&repository=github.com/prabathLK/PRABATH-MD&branch=main&env[BOT_NUMBER]&env[SESSION_ID]&env[PASSWORD]&env[GITHUB_USERNAME]&env[GITHUB_AUTH_TOKEN]&name=prabath-md)
<br>


<br>

## `FORK MANI OFFICIAL NEWS BOT` 👇

[![FORK MANI-NEWS-BOT-](https://img.shields.io/badge/FORK%20-MANI.OFC.NEWS.BOT%20-white)](https://github.com/MANI-OFC-NEWS-BOT-24/MANI-NEWS-24HOURS/fork)



<br>

## `OTHER DETAILS` 👇
![repo views](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FprabathLK%2FPRABATH-MD&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false)

![forks](https://img.shields.io/github/forks/prabathLK/PRABATH-MD?label=Forks&style=social)

![stars](https://img.shields.io/github/stars/prabathLK/PRABATH-MD?style=social)


<br>

## 👨‍💻 **`CONTACT TO NEWS-BOT OWNER 👇`** 


<a href="https://github.com/MANI-OFC-NEWS-BOT-24/MANI-NEWS-24HOURS"><img src="https://telegra.ph/file/84f07ad063a0358cbc437.jpg" width=80 height=80></a> 


<br>

## 💦 CONTACT TO WHATSAPP 👇
<a href="https://wa.me/94760863952"><img src="https://telegra.ph/file/67bc1b6b6c462b6adb49d.jpg" width=350 height=35></a>




## 💦 CONTACT TO TELEGRAM 👇
<a href="https://t.me/MANIOFFICIALTEAM"><img src="https://telegra.ph/file/19046d9142af5628e971b.jpg" width=350 height=35></a> 


<br>

## `MANI OFC NEWS BOT පිලිබද කෙටි හැදින්වීම` 👇
### 💯 (ඔබට මෙම බොට් හරහා ශ්‍රී ලංකාවෙහි දිනපතා නිකුත් වන පුවත් එවෙලේම whatsapp පණිවිඩයක් මාර්ගයෙන් ගෙන්වා ගැනීමට හැකියාව ඇති අතර මෙම බොට් වරයා මගින් නිකුත් කරනු ලබන්නෙ හිරු මාද්‍යජාලය මගින් ඔව්න්ගෙ Official වෙබඩවියේ පල කරන ලද 100% සත්‍ය තොරතුරුවේ.)


<br>

## *`💦 THANKS FOR USING MANI OFFICIAL NEWS BOT`* 📡


<br>

### 💥 CREATED BY :- GIHINDU MANTHILA
### 💥 POWERD BY :- MANI OFFICAL NEWS TEAM
