const { fetchJson } = require('../lib/functions')
const config = require('../config')
const { cmd, commands } = require('../command')


cmd({
    pattern: "settings",
    alias: ["setting,settings"],
    react: "⚙️",
    desc: "update bot settings",
    category: "updates",
    filename: __filename
},
async(conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try{
if (!isOwner) return await reply("*⚠️ This command is only for the Dark Yash owner ‼️*")

const caption = `*♻️ BLACK FIRE MD SETTING UPDATER ♻️*

*┌────────────────╮*
*├*🗣️ \`Use the following command to change the Alive Image.\`

*├*♻️ *.update ALIVE_IMG :* Please enter your image url.
*└────────────────╯*

*┌────────────────╮*
*├*🗣️ \`Use the following command to change the prefix.\`

*├*♻️ *.update PREFIX :* Please enter a symbol of your choice.
*└────────────────╯*

*┌────────────────╮*
*├*🗣️ \`Use the following command to change the Mode.\`

*├*♻️ *.update MODE :* Please enter public, group or private according to your choice.
*└────────────────╯*

*┌────────────────╮*
*├*🗣️ \`Use the following command to turn auto status read on & off.\`

*├*♻️ *.update AUTO_READ_STATUS :* Please enter ture or felse.
*└────────────────╯*

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*`
       
await conn.sendMessage(from,  { image: { url: 'https://telegra.ph/file/2b01f36354e9ced98540d.jpg' }, caption: caption }, { quoted: mek })

}catch(e){
console.log(e)
reply(`⚠️ *DARK YASH MD Error➤*‼️ ${e}`)
}
})
