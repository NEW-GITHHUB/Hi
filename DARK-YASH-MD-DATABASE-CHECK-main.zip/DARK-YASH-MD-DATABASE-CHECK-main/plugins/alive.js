const {readEnv} = require('../lib/database')
//const {cmd , commands} = require('../command')
const {cmd , commands} = require('../command')
const os = require("os")
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')
const fs = require('fs');
const path = require('path');
const voiceFilePath = path.join(__dirname, '../lib/dark_yash_md_sound.mp3');
const moment = require('moment-timezone');


cmd({
    pattern: "alive",
    desc: "Check bot online or no.",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
await conn.sendMessage(from, { react: { text: '👋', key: mek.key }});

const currentTime = moment().tz('Asia/Colombo').format('hh:mm:ss A');   
const currentDate = moment().tz('Asia/Colombo').format('YYYY-MM-DD');


function getTimeOfDay() {
const hour = moment().tz('Asia/Colombo').hour();
if (hour >= 0 && hour < 12) {
return 'Good morning 💐🌞';
} else if (hour >= 12 && hour < 15) {
return 'Good Afternoon';
} else if (hour >= 15 && hour < 18) {
return 'Good Evening 🌟';
} else if (hour >= 18 && hour < 24) {
return 'Good night! 💤🛌💤';
}
}
let desc = `*👋 Hellow ${pushname} ${getTimeOfDay()}*

🎊 I am - *🧛 DARK-YASH-MD 🧛*

┏──────────────⚯➤
┃ ⏰ *Now Time:-* ${currentTime}
┃ 📅 *Today Date:-* ${currentDate}
┃ 👨‍💻 *Owner:-* ᴍʀͥ ᴍᴀͣɴͫᴛʜɪʟᴀ
┃ 🧬 *Version:-* 1.0.0
┗───────────────⚯➤
`
/*await conn.sendMessage(from, { audio: fs.readFileSync('./black_fire.mp3') , ptt: true  , mimetype: 'audio/mpeg'}, { quoted: mek })*/
await conn.sendMessage(from,{ audio: { url:voiceFilePath }, mimetype:'audio/mpeg', ptt: true },{ quoted: mek });
await conn.sendMessage(from, {
text:desc + config.ALIVE_MSG, 
contextInfo: {
externalAdReply: {
title: "🧛DARK-YASH-MD🧛",
body: pushname,
mediaType: 1,
previewType: 1,
renderLargerThumbnail: true,
thumbnailUrl: config.ALIVE_IMG,
sourceUrl: "https://whatsapp.com/channel/0029Va5dJKyJpe8oqDXUjI3x"
}
}
}, {quoted: mek})
    
}catch(e){
console.log(e)
reply(`⚠️ *DARK YASH MD ERRO➤*‼️ ${e}`)
}
})




cmd({
    pattern: "today",
    desc: "Check bot online or no.",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
await conn.sendMessage(from, { react: { text: '🌞', key: mek.key }});

const currentTime = moment().tz('Asia/Colombo').format('hh:mm:ss A');   
const currentDate = moment().tz('Asia/Colombo').format('YYYY-MM-DD');


function getTimeOfDay() {
const hour = moment().tz('Asia/Colombo').hour();
if (hour >= 0 && hour < 12) {
return 'Good morning 💐🌞';
} else if (hour >= 12 && hour < 15) {
return 'Good Afternoon';
} else if (hour >= 15 && hour < 18) {
return 'Good Evening';
} else if (hour >= 18 && hour < 24) {
return 'Good night! 💤🛌💤';
}
}
let desc = `┏─❖
│「 𝗛𝗶 👋 」
┗┬❖ 「 *${pushname}* 」
   │✑
   │✑ *🌟 TODAY DATE & TIME 🌟*
   │✑ ⦁────────────────⦁
   │✑  *❄️ IT'S NOW:*
   │✑   ${getTimeOfDay()}
   │✑  *⏰ NOW TIME :*
   │✑   ${currentTime}
   │✑  *📆 TODAY DATE*
   │✑   ${currentDate}
   ┗─────────────────┈ ⳹

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*`

let df = await conn.sendMessage(from, { image: {url: config.ALIVE_IMG}, caption: desc }, { quoted: mek });
await conn.sendMessage(from, { react: { text: '✨', key: df.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '🌝', key: df.key } });
}, 1000);
    
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '🌼', key: df.key } });
}, 2000);

setTimeout(async () => {
conn.sendMessage(from, { react: { text: '💖', key: df.key } });
}, 3000);

setTimeout(async () => {
conn.sendMessage(from, { react: { text: '🌻', key: df.key } });
}, 4000);

setTimeout(async () => {
conn.sendMessage(from, { react: { text: '🌟', key: df.key } });
}, 5000);

setTimeout(async () => {
conn.sendMessage(from, { react: { text: '🎋', key: df.key } });
}, 6000);

setTimeout(async () => {
conn.sendMessage(from, { react: { text: '🌩️', key: df.key } });
}, 7000);
    
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '💐', key: df.key } });
}, 8000);

}catch(e){
console.log(e)
reply(`⚠️ *DARK YASH MD ERRO➤*‼️ ${e}`)
}
});






cmd({
    pattern: "updates",
    alias: ["updates"],
    desc: "download tt videos",
    category: "download",
    filename: __filename
},
async(conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {
await conn.sendMessage(from, { react: { text: '🔄', key: mek.key }});

setTimeout(async () => {   
await conn.sendMessage(from , { text: '📥 *Downloading Update...*' }, { quoted: mek });
}, 1000);
 
setTimeout(async () => {   
await conn.sendMessage(from , { text: '🛡️ *Installing Update...*'}, { quoted: mek });
}, 3000);

setTimeout(async () => {   
await conn.sendMessage(from , { text: '🔄 *Finishing the update and restarting...*'}, { quoted: mek });
const { exec } = require("child_process") 
exec('pm2 restart all')
}, 5000);

setTimeout(async () => {   
await conn.sendMessage(from , { text: '*💐 Dark Yash md new update has been updated enjoy...*' }, { quoted: mek });
}, 8000);
    
setTimeout(async () => {
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }});
}, 9000);

} catch (e) {
console.log(e)
reply(`⚠️ *DARK YASH MD ERRO➤*‼️ ${e}`)
}
});

