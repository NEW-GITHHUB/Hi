const config = require('../config')
const { cmd, commands } = require('../command')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson } = require('../lib/functions')
const axios = require('axios')
const cheerio = require('cheerio')

cmd({
    pattern: "tiks",
    alias: ["tikss"],
    use: '.tiktoksearch <query>',
    react: "🔎",
    desc: "Search and DOWNLOAD VIDEOS from TikTok.",
    category: "search",
    filename: __filename

},
async (conn, mek, m, { from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {
//if (!q) await conn.sendMessage(from, { react: { text: '⁉️', key: mek.key } });
//if (!q) return reply('⚠️ *Please give me a tiktok title dear*‼️')
if(!q) {
const rc = await conn.sendMessage(from,{text:"*❌ Please Give Me a Tiktok Title dear.*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
let mal = await fetchJson('https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=' + q)
let data = mal.data

//if (data.length < 1) return await conn.sendMessage(from, { text: "❌ *I couldn't find anything*" }, { quoted: mek })
if(data.length < 1) {
const rec = await conn.sendMessage(from,{text:"❌ *I Couldn't find anything.*"},{quoted:mek})
const reactionMessage = {react: {text: "❗", key: rec.key }}
return await conn.sendMessage(from, reactionMessage)
}
const msg = `*🔎 DARK YASH MD TIKTOK VIDEO SEARCH 🔍*\n\n▰▱▰▱▰▱▰▱▰▱▰▱▰`

let numberMessage = `${msg}\n\n`

// Search results are sliced into chunks of 10 videos
let chunkSize = 10
let chunkedData = []
for (let i = 0; i < data.length; i += chunkSize) {
chunkedData.push(data.slice(i, i + chunkSize))
}

// Choose the first chunk (first 10 results)
let displayData = chunkedData[0]
global.tiktokSearchResults = displayData // Store only the first 10 results

displayData.forEach((v) => { // Removed the index parameter
numberMessage += `*\`TITLE:-\`* *${v.title}*\n\n*\`URL:-\`* ${v.url}\n\n▰▱▰▱▰▱▰▱▰▱▰▱▰\n\n`
})
numberMessage += `*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*`

await conn.sendMessage(from, { text: numberMessage }, { quoted: mek })

}catch(e){
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
});
