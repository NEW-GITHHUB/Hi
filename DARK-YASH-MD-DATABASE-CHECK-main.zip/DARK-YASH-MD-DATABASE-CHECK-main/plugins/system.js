const config = require('../config')
const {cmd , commands} = require('../command')
const os = require("os")
const {runtime} = require('../lib/functions')

cmd({
    pattern: "system",
    alias: ["os"],
    desc: "Check bot system info.",
    category: "main",
    use: '.system',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, isCreator, prefix, isMod, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(os.hostname().length == 12 ) hostname = 'replit'
else if(os.hostname().length == 36) hostname = 'heroku'
else if(os.hostname().length == 8) hostname = 'koyeb'
else hostname = os.hostname()
let maru =`*🫧 DARK YASH SYSTEM INFORMATION 📡*

*┏─────────────────────────┓*
*├ ⏰ \`Uptime :-\`*  ${runtime(process.uptime())}
*├ 📟 \`Ram usage :-\`* ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
*├ ⚙️ \`Platform :-\`*  ${os.hostname()}
*├ 👨‍💻 \`Owners :-\`* M.G.Manthila
*├ 🧬 \`Version :-\`* 1.0.0
*┗─────────────────────────┛*
`

const mass = await conn.sendMessage(from,{image:{url:"https://telegra.ph/file/f34310079839a9ba02beb.jpg"},caption:maru},{quoted:mek})
/*return await conn.sendMessage(from, { react: { text: "📟", key: maru.key } })*/
await conn.sendMessage(m.chat, {  react: {  text: "📟",   key: mass.key }})

}catch(e){
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
})
