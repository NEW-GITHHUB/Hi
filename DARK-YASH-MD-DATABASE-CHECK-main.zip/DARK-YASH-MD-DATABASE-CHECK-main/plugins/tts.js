const config = require('../config')
const {cmd , commands} = require('../command')
const { fetchJson } = require('../lib/functions')
const googleTTS = require('google-tts-api');

cmd({
    pattern: "tts",
    desc: "google tts",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
await conn.sendMessage(from, { react: { text: '🎙️', key: mek.key } });
    
if(!q) {
const rc = await conn.sendMessage(from,{text:"❌ *Please Give me a text.*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
const ttsurl = googleTTS.getAudioUrl(q, {
                lang: "si",
                slow: false,
                host: "https://translate.google.com",
            });

let df = await conn.sendMessage(from, { text: `*♻️ Generating and Uploading your Voice Message...*` }, { quoted: mek });

           let aud = await conn.sendMessage(from, {
                audio: {
                    url: ttsurl,
                },
                mimetype: "audio/mpeg",
                fileName: `.random.tts.mp3.ptt`,
                ptt: true ,
            }, {
                quoted: mek,
            });                            

await conn.sendMessage(from, { react: { text: '🎤', key: aud.key } });
await conn.sendMessage(from, { react: { text: '✅', key: df.key } });

}catch(e){
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
});
