const {readEnv} = require('../lib/database')
const {cmd , commands} = require('../command')
const fs = require('fs')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')
const gis = require('async-g-i-s');
const {unsplash, pixabay} = require("@sl-code-lords/image-library")

cmd({
    pattern: "img",
    desc: "Download images based on keywords or URLs",
    category: "download",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, reply }) => {
try {
const config = await readEnv();
const iAm = fs.readFileSync('isMe.txt', 'utf8').trim()

await conn.sendMessage(from, { react: { text: '🖼️', key: mek.key } });
if(!q) {
const rc = await conn.sendMessage(from,{text:"❌ *Please provide an image title or URL ‼️*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
// Check if the input is a URL or a search term
const query = isUrl(q) ? q : `keyword ${q}`;
        
// Search for the image using the provided keyword or URL
const images = await gis(query);
if(!images || images.length === 0) {
const rcc = await conn.sendMessage(from, {text:"⚠️ *Could not retrieve images from the provided title or URL*‼️"},{quoted:mek})
const reactionMessage = {react: {text: "❗", key: rcc.key }}
return await conn.sendMessage(from, reactionMessage)
}
// Limit to 5 images
const limitedImages = images.slice(0, 5);
        
let desc = `*┠─❲ 🧛 DARK-YASH-MD 🧛 ❳─┨*

     *🖼️ IMAGE DOWNLOADER 🖼️*

*🔢 Please reply with the number of the option you want...* 

┏──────────────────┓
┠ 1 | *Normal Image Type*
┠ 2 | *Document Image Type*
┗──────────────────┛

*🎗️ Text ~:* ${q}

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ  ⦁*
`;

// Send the options message
const sentMsg = await conn.sendMessage(from,  { image: { url: 'https://telegra.ph/file/f34310079839a9ba02beb.jpg' }, caption: desc }, { quoted: mek });
const messageID = sentMsg.key.id;

// Listen for user response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;

//-----------------------Non Button Mode Change-----------------------------------
const senderv2 = mek.key.fromMe ? (conn.user.id.split(':')[0] + '@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumberv2 = senderv2.split('@')[0]
let owner = iAm.includes(senderNumberv2) || config.OWNER.includes(senderNumberv2)
if(!owner && config.MODE === "private") return
if(!owner && isGroup && config.MODE === "inbox") return
if(!owner && !isGroup && config.MODE === "groups") return
//--------------------------------------------------------------------------------

    
// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1','2'].includes(messageType)) {
// React to download
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
// React to upload
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

if (messageType === '1') {
// Send Normal Images
for (const img of limitedImages) {
await conn.sendMessage(from, { image: { url: img.url }, caption: "*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*" }, { quoted: mek });
}
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
} else if (messageType === '2') {
// Send Document Types
for (const img of limitedImages) {
await conn.sendMessage(from, { document: { url: img.url }, mimetype: "image/jpeg", fileName: "image.jpg", caption: "*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*" }, { quoted: mek });
}
await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
} else {
// Invalid option
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1 or 2) ‼️*' }, { quoted: mek });
}
}
}
});

} catch (e) {
console.log(e);
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*`"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
}
});


/*const {readEnv} = require('../lib/database')
//const config = require('../config')
const { cmd, commands } = require('../command')
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')
const gis = require('async-g-i-s');
const {unsplash, pixabay} = require("@sl-code-lords/image-library")

cmd({
    pattern: "img",
    react: '🖼️',
    alias: ["gimage"],
    
    category: "download",
    use: '.img car',
    filename: __filename
},
async(conn, mek, m,{from, l, prefix, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
if (!q) return await  reply(imgmsg)
const results = await gis(q);
let data = results.slice(0, 100)
if (data.length < 3) return await conn.sendMessage(from, { text: N_FOUND }, { quoted: mek } )
    const rows = []
let nombor = 1
for (var i = 0; i < data.length; i++)


 {

    rows.push({
        header: '',
        title: `${nombor++}`,
        description: `${data[i].width+'x'+data[i].height}`,
        id: `.dimg ${data[i].url}`
    })

}
let buttons = [{
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
            display_text: config.BTN,
            url: config.BTN_URL,
            merchant_url: config.BTN_URL
        }),
    },
    {
        name: "single_select",
        buttonParamsJson: JSON.stringify({
            title: 'SELECT :)',
            sections: [{
                title: 'please select you want',
                highlight_label: 'DARK-YASH-MD',
                rows: rows

            }]
        }),
    }

]

let MNG = `gh

`

let opts = {
    image: config.ALIVE_IMG,
    header: '',
    footer: config.FOOTER,
    body: MNG

}
return await conn.sendButtonMessage(from, buttons, m, opts)

} catch (e) {
    reply("🚩 Not Found !")
    console.log(e)
}
})
cmd({
    pattern: "img2",
    react: '🖼️',
    alias: ["unsplash"],
 
    category: "download",
    use: '.img2 car',
    filename: __filename
},
async(conn, mek, m,{from, l, prefix, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
if (!q) return await  reply(imgmsg)
const results = await unsplash.search({"query": q, page: 1})
let data = results
if (data.result.length < 1) return await conn.sendMessage(from, { text: N_FOUND }, { quoted: mek } )
    const rows = []
let nombor = 1
for (var i = 0; i < data.result.length; i++)


 {

    rows.push({
        header: '',
        title: `${nombor++}`,
        description:  '',
        id: `.dimg ${data.result[i]}`
    })

}
let buttons = [{
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
            display_text: config.BTN,
            url: config.BTN_URL,
            merchant_url: config.BTN_URL
        }),
    },
    {
        name: "single_select",
        buttonParamsJson: JSON.stringify({
            title: 'SELECT:)',
            sections: [{
                title: 'Please select a img you want',
                highlight_label: 'DARK SHUTER',
                rows: rows

            }]
        }),
    }

]

let MNG = `gh

`

let opts = {
    image: config.ALIVE_IMG,
    header: '',
    footer: config.FOOTER,
    body: MNG

}
return await conn.sendButtonMessage(from, buttons, m, opts)


} catch (e) {
    reply("🚩 Not Found !")
    console.log(e)
}
})


cmd({
    pattern: "img4",
    react: '🖼️',
    alias: ["bingimage","bingimg"],
    
    category: "download",
    use: '.img4 car',
    filename: __filename
},
async(conn, mek, m,{from, l, prefix, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const config = await readEnv();
if (!q) return await  reply(imgmsg)
const results = await fetchJson('https://api.akuari.my.id/search/bingimage?query=' + q)
let data = results.hasil
if (data.results.length < 1) return await conn.sendMessage(from, { text: N_FOUND }, { quoted: mek } )
    const rows = []
let nombor = 1
for (var i = 0; i < data.results.length; i++)


 {

    rows.push({
        header: '',
        title: `${data.results[i].title}`,
        description:  `${data.results[i].description}`,
        id: `.dimg ${data.results[i].direct}`
    })

}
let buttons = [{
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
            display_text: config.BTN,
            url: config.BTN_URL,
            merchant_url: config.BTN_URL
        }),
    },
    {
        name: "single_select",
        buttonParamsJson: JSON.stringify({
            title: 'SELECT :)',
            sections: [{
                title: 'please img you want',
                highlight_label: 'DARK-YASH-MD',
                rows: rows

            }]
        }),
    }

]

let MNG = `gh

`

let opts = {
    image: config.ALIVE_IMG,
    header: '',
    footer: config.FOOTER,
    body: MNG

}
return await conn.sendButtonMessage(from, buttons, m, opts)



} catch (e) {
    reply("🚩 Not Found !")
    console.log(e)
}
})

















cmd({
    pattern: "dimg",
    dontAddCommandList: true,
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
    await conn.sendMessage(from, { react: { text: '🔃', key: mek.key }})
    await conn.sendMessage(from, { image: { url: q }, caption: config.FOOTER }, { quoted: mek })
    await conn.sendMessage(from, { react: { text: '✔', key: mek.key }})
} catch (e) {
    reply("🚩 Not Found !")
    console.log(e)
}
})*/
