const config = require('../config')
const {cmd , commands} = require('../command')
const { fetchJson } = require('../lib/functions')

cmd({
    pattern: "wame",
    desc: "wame",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
await conn.sendMessage(from, { react: { text: '🪀', key: mek.key } });
if(!m.quoted)return reply("*⚠️ Give me user or quote user*")
    
let users = m.mentionedJid ? m.mentionedJid[0].split('@')[0] : m.quoted ? m.quoted.sender.split('@')[0] : q.replace('@')[0]

let df = await conn.sendMessage(from, { text: `*♻️ Generating and Uploading your Whatsapp Number URL...*` }, { quoted: mek });
let sendanswer = await conn.sendMessage(from, { text: `*📤 UPLOADED YOUR WA.ME URL*\n\n> *https://wa.me/${users}*\n\n*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*` }, { quoted: mek });

await conn.sendMessage(from, { react: { text: '🔗', key: sendanswer.key } });
await conn.sendMessage(from, { react: { text: '✅', key: df.key } });

//reply(`https://wa.me/${users}`)
}catch(e){
console.log(e)
reply(`⚠️ *Black Fire MD Error➤*‼️ ${e}`)
}
})
