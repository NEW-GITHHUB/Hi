const { fetchJson } = require('../lib/functions')
const config = require('../config')
const { cmd, commands } = require('../command')

cmd({
    pattern: "boom",
    alias: ["boom"],
    react: "👽",
    desc: "Send repeated text messages",
    category: "fun",
    filename: __filename
},
async(conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {

if(!isOwner) {
const rc = await conn.sendMessage(from,{text:"⛔ *THIS IS AN OWNER COMMAND.*"},{quoted:mek})
const reactionMessage = {react: {text: "⛔", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}       
// Check if the arguments are provided
if (args.length < 2) return reply(`Usage: .boom <number> <text> \nExample: .boom 10 Hello`)
        
// Extracting number and text from arguments
let count = parseInt(args[0])
let text = args.slice(1).join(" ")

// Limit count to 100 messages maximum
if (isNaN(count) || count < 1 || count > 100) return reply(`⚠️ Please provide a valid number between 1 and 100!`)
        
// Extracting number and text from arguments
for (let i = 0; i < count; i++) {
await conn.sendMessage(from, { text: text })
}

} catch (e) {
console.log(e)
let cf = await conn.sendMessage(from,{text:"🛑 *DARK YASH MD ERROR*"},{quoted:mek})
await conn.sendMessage(from, { react: { text: '❗', key: cf.key } });
}
})
