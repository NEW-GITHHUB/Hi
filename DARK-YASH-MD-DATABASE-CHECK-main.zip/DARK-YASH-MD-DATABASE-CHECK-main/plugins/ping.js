const config = require('../config')
const { cmd, commands } = require('../command')
const os = require("os")
const {runtime} = require('../lib/functions')

cmd({
        pattern: "ping",
        alias: ["speed"],
        desc: "Check bot\'s ping",
        category: "main",
        use: '.ping',
        filename: __filename
    },
    async (conn, mek, m, {
        from,
        reply
    }) => {
        try {
            let inital = new Date().getTime();
            let ping = await conn.sendMessage(from, {
                text: '```Pinging To index.js!!!```'
            }, {
                quoted: mek
            })
            let final = new Date().getTime();
            await conn.edit(ping, '*📍 Pong* -: *' + (final - inital) + ' ms* ')
          return await conn.sendMessage(from, { react: { text: "✔️", key: ping.key } }); 
        } catch (e) {
            reply('*Error !!*')
            console.log(e)
        }
    })
