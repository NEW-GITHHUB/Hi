const {cmd , commands} = require('../command')

cmd({
    pattern: "report",
    desc: "report to owners",
    category: "owner",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {

await conn.sendMessage(from, { react: { text: '📢', key: mek.key } });
    
if (!q && !(m.quoted && m.quoted.msg)) {
const rc = await conn.sendMessage(from,{text:"*⛔ Please mention a short message*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
    
if (!isOwner) {
const rcw = await conn.sendMessage(from,{text:"*⛔ THIS AN OWNER COMMAND*"},{quoted:mek})
const reactionMessage = {react: {text: "⛔", key: rcw.key }}
return await conn.sendMessage(from, reactionMessage)
}
    
if (m.quoted) {
const { type, ephemeralMessage } = m.quoted;
if (["documentMessage", "audioMessage", "videoMessage", "imageMessage"].includes(type) || ephemeralMessage) {
const rcf = await conn.sendMessage(from,{text:"*⛔ I can only send text massages*"},{quoted:mek})
const reactionMessage = {react: {text: "❗", key: rcf.key }}
return await conn.sendMessage(from, reactionMessage)
}
}

const messageText = m.quoted && m.quoted.msg ? m.quoted.msg : q;
const charCount = messageText.trim().length;  // count characters instead of words

if (charCount > 500) {
const rce = await conn.sendMessage(from,{text:`*❌ The message contains too many characters (${charCount} characters). Please provide a text with 500 characters or less*`},{quoted:mek})
const reactionMessage = {react: {text: "❗", key: rce.key }}
return await conn.sendMessage(from, reactionMessage)
}

let dt = await conn.sendMessage(from,{text:"*Your report has been sent to Dark Yash MD founder* ✅"},{quoted:mek})
let de = await conn.sendMessage("94743218422@s.whatsapp.net",{text:`jid:${from}\n\n${m.quoted.msg}`})
await conn.sendMessage(from, { react: { text: '✅', key: dt.key } });
await conn.sendMessage(from, { react: { text: '📩', key: de.key } });


} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR.*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
});
