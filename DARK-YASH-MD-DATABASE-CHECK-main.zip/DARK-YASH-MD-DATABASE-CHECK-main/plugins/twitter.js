const { fetchJson } = require('../lib/functions')
const config = require('../config')
const { cmd, commands } = require('../command')

//===============================FETCH API URL===============================

let baseUrl;
(async () => {
    let baseUrlGet = await fetchJson(`https://raw.githubusercontent.com/prabathLK/PUBLIC-URL-HOST-DB/main/public/url.json`)
    baseUrl = baseUrlGet.api
})();


const yourName = "*BLACK FIRE MD*";


cmd({
    pattern: "tw",
    alias: ["twdl"],
    desc: "download tw videos",
    category: "download",
    filename: __filename
},
async(conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
try {
if (!q && !q.startsWith("https://")) {
const rc = await conn.sendMessage(from,{text:"❌ *Please Give me a URL*"},{quoted:mek})
const reactionMessage = {react: {text: "❓", key: rc.key }}
return await conn.sendMessage(from, reactionMessage)
}
//fetch data from api  
let data = await fetchJson(`${baseUrl}/api/twitterdl?url=${q}`)
let ttcp = `*┠─❲ 🧛 DARK-YASH-MD 🧛 ❳─┨*

    *💢 X-TWITTER DOWNLOADER 💢*

🔢 *Please reply with the number you want to select:*

*\`[1] Twitter Video\`*
        1.1 | 🔋 HD QUALITY
        1.2 | 🪫 SD QUALITY

*\`[2] Twitter Audio\`*
        2.1 | 🎶 Audio file
        2.2 | 📁 Document file
        2.3 | 🎤 Voice cut [ptt]

*🖇️ URL:* ${q}

*⦁ ᴅᴀʀᴋ-ʏᴀꜱʜ-ᴍᴅ ʙʏ ᴍᴀɴɪ ⦁*
`

//==========NON BUTTON MSG SEND==========

const sentMsg = await conn.sendMessage(from, { image: { url: 'https://telegra.ph/file/8932f8350240ebb87c4ee.jpg' }, caption: ttcp }, { quoted: mek });
const messageID = sentMsg.key.id; // Save the message ID for later reference
await conn.sendMessage(from, { react: { text: '🔢', key: sentMsg.key } });

// Listen for the user's response
conn.ev.on('messages.upsert', async (messageUpdate) => {
const mek = messageUpdate.messages[0];
if (!mek.message) return;
const messageType = mek.message.conversation || mek.message.extendedTextMessage?.text;
const from = mek.key.remoteJid;
const sender = mek.key.participant || mek.key.remoteJid;


// Check if the message is a reply to the previously sent message
const isReplyToSentMsg = mek.message.extendedTextMessage && mek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

if (isReplyToSentMsg) {
// Handle correct responses (1, 2, 3, or 4)
if (['1.1', '1.2', '2.1' , '2.2', '2.3'].includes(messageType)) {
//React to the (download downloading the fil)
await conn.sendMessage(from, { react: { text: '⬇️', key: mek.key } });
//React to the upload (sending the file)
setTimeout(async () => {
conn.sendMessage(from, { react: { text: '⬆️', key: mek.key } });
}, 1000);

if (messageType === '1.1') {
// Handle option 2 (Tiktok Video No Watermark)
let nowm = await conn.sendMessage(from, { video: { url: data.data.data.HD }, mimetype: "video/mp4", caption: `- HD\n\n ${yourName}` }, { quoted: mek })
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: nowm.key } });

} else if (messageType === '1.2') {
// Handle option 4 (Tiktok Video With Watermark)
let nowmm = await conn.sendMessage(from, { video: { url: data.data.data.SD }, mimetype: "video/mp4", caption: `- SD \n\n ${yourName}` }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎥', key: nowmm.key } });

} else if (messageType === '2.1') {
// Handle option 5 (Tiktok Audio File)
let audtt = await conn.sendMessage(from, { audio: { url: data.data.data.audio }, mimetype: "audio/mpeg" }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎶', key: audtt.key } });

} else if (messageType === '2.2') {
// Handle option 5 (Tiktok Audio File)
let audtt = await conn.sendMessage(from, { audio: { url: data.data.data.audio }, mimetype: "audio/mpeg" }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎶', key: audtt.key } });

} else if (messageType === '2.3') {
// Handle option 5 (Tiktok Audio File)
let aud = await conn.sendMessage(from, { audio: { url: data.data.data.audio }, mimetype: "audio/mpeg", ptt: true }, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key } });
await conn.sendMessage(from, { react: { text: '🎤', key: aud.key } });
}

} else {
// React with invalid input
await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
// Invalid option
await conn.sendMessage(from, { text: '*⚠️ Invalid option! Please enter a valid number (1.1-1.2 , 2.1-2.3) ‼️*' }, { quoted: mek });
}    
}
});

} catch (e) {
let dm = await conn.sendMessage(from, { text: "🛑 *DARK YASH MD ERROR*"}, { quoted: mek });
await conn.sendMessage(from, { react: { text: '❗', key: dm.key } });
console.log(e)
}
})
